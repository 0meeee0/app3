<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\Images;

class Article extends Model
{
    use HasFactory;
    public static function isSlugExists($slug)
    {
        $slugs = self::select('slug')->get();
        foreach ($slugs as $key) {
            if ($key->slug === $slug) {
                return true;
            }
        }

        return false;
    }

    public static function get_all_by_category($category_id)
    {
        $articles = self::select('articles.*', 'images.file_name')
            ->where('category_id', '=', $category_id)
            ->join('images', 'articles.image_id', '=', 'images.id')
            ->take(4)
            ->get();

        return $articles;
    }
}
