<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SocialMedia extends Model
{
    use HasFactory;
    protected $table = "social_media";
    protected $fillable = ['name', 'link'];

    public static function get_social_link_by_name($name)
    {
        return self::where('name', '=', $name)->first();
    }
}
