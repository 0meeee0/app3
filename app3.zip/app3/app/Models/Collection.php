<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collection extends Model
{
    use HasFactory;

    public static function get_images($collection)
    {
        $images = self::select('images.*')
            ->join('collection_images', 'collections.id', '=', 'collection_images.collection_id')
            ->join('images', 'collection_images.image_id', '=', 'images.id')
            ->where('collections.id', '=', $collection)
            ->get();
        return $images;
    }
    public static function get_index()
    {
        $collections = Collection::join('images', 'collections.banner_id', '=', 'images.id')
            ->select('collections.*', 'images.file_name')
            ->take(4)
            ->get();

        return $collections;
    }
}
