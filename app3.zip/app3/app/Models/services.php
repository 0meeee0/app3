<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

class services extends Model
{
    use HasFactory;

    public static function isSlugExists($slug)
    {
        $slugs = self::select('slug')->get();
        foreach ($slugs as $key) {
            if ($key->slug === $slug) {
                return true;
            }
        }

        return false;
    }

    public static function filterImages($existingImages, $removedImages)
    {
        $existingImagesFlat = array_map('basename', $existingImages);
        $removedImagesFlat = array_map('basename', $removedImages);

        // Loop through existing images and add to keptImages if not removed
        $keptImages = [];
        foreach ($existingImagesFlat as $imageName) {
            if (!in_array($imageName, $removedImagesFlat)) {
                $keptImages[] = $imageName;
            }
        }

        return $keptImages;
    }

    public static function handleUploadedImages($uploadedImages, $keptImages)
    {
        if (is_array($uploadedImages)) {
            foreach ($uploadedImages as $image) {
                $imageName = uniqid('service_') . '.' . $image->getClientOriginalExtension();
                $imagePath = 'uploads/services/' . $imageName;

                // Save the image to the public/uploads/services directory
                Storage::disk('public')->put($imagePath, file_get_contents($image));

                // Store the image name in the $keptImages array
                $keptImages[] = $imageName;
            }
        }
        return $keptImages;
    }

    public static function generateUniqueSlug($title)
    {
        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($title));

        $count = 1;
        while (self::isSlugExists($slug)) {
            $slug = $slug . '-' . $count;
            $count++;
        }
        
        return $slug;
    }
}
