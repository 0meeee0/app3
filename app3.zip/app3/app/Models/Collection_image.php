<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Collection_image extends Model
{
    use HasFactory;

    protected $table = "collection_images";
    protected $primaryKey = 'image_id'; // Specify the non-standard primary key
    public $incrementing = false; // Set to false to indicate non-incrementing primary key
    protected $fillable = ['collection_id', 'image_id'];

    // Custom delete method to use image_id for deletion
    public function deleteWithImageId()
    {
        return $this->where('image_id', $this->image_id)->delete();
    }

    public static function get_iamges_by_collection($collection_id)
    {
        return self::select('images.file_name')->join('images', 'collection_images.image_id', '=', 'images.id')->where('collection_id', '=', $collection_id)->get();
    }
}
