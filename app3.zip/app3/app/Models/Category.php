<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    public static function isSlugExists($slug)
    {
        $slugs = self::select('slug')->get();
        foreach ($slugs as $key) {
            if ($key->slug === $slug) {
                return true;
            }
        }

        return false;
    }

    public static function get_all_published()
    {
        $all = self::select('categories.*', 'images.file_name')
        ->join('images', 'categories.banner_id', '=', 'images.id')
        ->where('categories.publish', '=', 1)
        ->get();
        
        return $all;
    }
    public static function get_all()
    {
        return Category::select('*')->get();
    }
    
    public static function get_all_published_num($num)
    {
        $cat = self::select('categories.*', 'images.file_name')
            ->join('images', 'categories.banner_id', '=', 'images.id')
            ->where('categories.publish', '=', 1)
            ->take($num)
            ->get();
            
        return $cat;
    }
}
