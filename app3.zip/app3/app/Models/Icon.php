<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Icon extends Model
{
    use HasFactory;

    protected $table = 'icons';
    protected $fillable = ['file_name'];


    public static function get_all_icons()
    {
        $icons = self::select('*')->get();
        return $icons;
    }
}
