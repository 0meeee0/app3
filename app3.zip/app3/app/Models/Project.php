<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    public static function get_all_published_by_id($id)
    {
        $project = self::join('images', 'projects.banner_id', '=', 'images.id')
            ->join('project_categories', 'projects.category_id', '=', 'project_categories.id')
            ->select('projects.*', 'images.file_name', 'project_categories.name')
            ->where('projects.id', '=', $id)
            ->get();

        return $project;
    }
    public static function get_all_published()
    {
        $projects = self::join('images', 'projects.banner_id', '=', 'images.id')
            ->join('project_categories', 'projects.category_id', '=', 'project_categories.id')
            ->select('projects.*', 'images.file_name', 'project_categories.name')
            ->where('projects.publish', '=', true)
            ->get();

        return $projects;
    }
}
