<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class DevisEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $societe;
    public $email;
    public $phone;
    public $adress;
    public $code_postale;
    public $ville;
    public $demande;
    
    
    public function __construct($societe, $email, $phone, $adress, $code_postale, $ville, $demande)
    {
        $this->societe = $societe;
        $this->email = $email;
        $this->phone = $phone;
        $this->adress = $adress;
        $this->code_postale = $code_postale;
        $this->ville = $ville;
        $this->demande = $demande;
    }

    public function build()
    {
        return $this->view('Front.emails.devis');
    }

    public function envelope()
    {
        return new Envelope(
            /* subject: 'Devis Email', */
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */
    public function content()
    {
        return new Content(
            /* view: 'view.name', */
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }
}
