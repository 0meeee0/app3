<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Blog_category;
use App\Models\Setting;
use App\Models\Content;

class Blog_categoryController extends Controller
{
    public function index()
    {
        $categories = Blog_category::all();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blogCategory.index', [
            'categories' => $categories,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function create()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blogCategory.create', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);

        $category = new Blog_category();
        $category->title = $data['title'];
        $category->description = $data['description'];

        if ($category->save()) {
            return redirect()->back()->with('success', 'Categorie ajouté avec succès');
        } else {
            return redirect()->back()->with('error', 'Categorie n\'est pas ajouté ! essayer à nouveau.');
        }
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $category = Blog_category::findOrFail($id);
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blogCategory.edit', [
            'category' => $category,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);

        $category = Blog_category::findOrFail($id);
        $category->title = $data['title'];
        $category->description = $data['description'];

        if ($category->save()) {
            return redirect()->back()->with('success', 'Categorie modifié avec succès');
        } else {
            return redirect()->back()->with('error', 'Categorie n\'est pas modifié ! essayer à nouveau.');
        }
    }

    public function destroy($id)
    {
        $category = Blog_category::findOrFail($id);
        try {

            if ($category->delete()) {
                return redirect()->back()->with('success', 'Categorie a été supprimé avec succès');
            }

            return redirect()->back()->with('error', 'Categorie n\'est pas supprimé ! essayer à nouveau.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Categorie n\'est pas supprimé ! essayer à nouveau.');
        }
    }
}
