<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\services;
use Illuminate\Support\Facades\Storage;
use App\Models\Setting;
use App\Models\Content;

class ServiceController extends Controller
{
    public function index(Request $request)
    {
        if ($request->has('search')) {
            $services = services::select('services.*', 'images.file_name')
                ->join('images', 'services.banner_id', '=', 'images.id')
                ->where('services.title', 'like', '%' . $request->input('search') . '%')
                ->whereOr('services.short_description', 'like', '%' . $request->input('search') . '%')
                ->whereOr('services.description', 'like', '%' . $request->input('search') . '%')

                ->get();
        } else {
            $services = services::select('services.*', 'images.file_name')
                ->join('images', 'services.banner_id', '=', 'images.id')
                ->get();
        }

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.services.index', [
            'services' => $services,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function create()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.services.create', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'short_description' => 'required',
            'selecteImages' => 'required',
        ]);

        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($data['title']));

        $count = 1;
        while (services::isSlugExists($slug)) {
            $slug = $slug . '-' . $count;
            $count++;
        }

        $service = new services();
        $service->title = $data['title'];
        $service->description = $data['description'];
        $service->short_description = $data['short_description'];
        $service->slug = $slug;
        $service->banner_id = $data['selecteImages'];
        $imagePaths = [];

        foreach ($request->file('images') as $image) {
            $imageName = uniqid('service_') . '.' . $image->getClientOriginalExtension();
            $imagePath = 'uploads/services/' . $imageName;

            // Save the image to the public/uploads/services directory
            Storage::disk('public')->put($imagePath, file_get_contents($image));

            // Store the image name in the $imagePaths array
            $imagePaths[] = $imageName;
        }

        // Save the image names as JSON in the Service model's 'images' column
        $service->images = json_encode($imagePaths);

        if ($service->save()) {
            return redirect()->back()->with('success', 'Service ajouté avec succès');
        }

        return redirect()->back()->with('error', 'Service n\'est pas ajouté ! essayer à nouveau.');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $service = services::select('services.*', 'images.id as img_id', 'images.file_name')
            ->join('images', 'services.banner_id', '=', 'images.id')
            ->where('services.id', '=', $id)
            ->first();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.services.edit', [
            'service' => $service,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function update(Request $request, $id)
    {
        // Validate the incoming request data
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'short_description' => 'required',
            'selecteImages' => 'required',
        ]);

        // Generate a unique slug
        $slug = services::generateUniqueSlug($data['title']);

        // Find the service record by ID
        $service = services::findOrFail($id);

        // Update service properties
        $service->title = $data['title'];
        $service->description = $data['description'];
        $service->short_description = $data['short_description'];
        $service->slug = $slug;
        $service->banner_id = $data['selecteImages'];

        // Retrieve existing and removed images
        $existingImages = json_decode($service->images);
        $removedImages = json_decode($request->input('deletedImages', '[]'));

        // Filter out removed images
        if ($existingImages && $removedImages) {
            $keptImages = services::filterImages($existingImages, $removedImages);
            $keptImages = services::handleUploadedImages($request->file('images'), $keptImages);
        } else {
            // Handle new uploaded images
            $keptImages = $existingImages;
            $keptImages = services::handleUploadedImages($request->file('images'), $keptImages);
        }

        // Update the images property
        $service->images = $keptImages;

        // Save the updated service
        if ($service->save()) {
            return redirect()->back()->with('success', 'Service modifié avec succès');
        }

        return redirect()->back()->with('error', 'Service n\'est pas modifié ! Essayer à nouveau.');
    }


    public function destroy($id)
    {
        $service = services::findOrFail($id);
        try {
            $service->delete($id);
            return redirect()->back()->with('success', 'Service supprimé avec succès');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', 'Service n\'est pas supprimé ! essayer à nouveau.');
        }
    }
}
