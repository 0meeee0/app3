<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactForm;

class ContactController extends Controller
{
    public function showForm()
    {
        return view('contact');
    }

    public function send(Request $request)
    {
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->subject,
            'message' => $request->message
        ];
        
        Mail::to('baidou.abd@gmail.com')->send(new ContactForm($data));
        
        return redirect()->back()->with('alert', 'Votre message a été envoyé avec succès!');
        
    }
}
