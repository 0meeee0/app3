<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Image;
use App\Models\Icon;
use Intervention\Image\Facades\Image as InterventionImage;
use Illuminate\Support\Facades\Log;

class DropzoneController extends Controller
{
    public function upload_image(Request $request)
    {
        $image = $request->file('file');

        // Check if the file is an image
        if ($image->isValid() && in_array($image->getClientOriginalExtension(), ['jpeg', 'jpg', 'png', 'gif', 'webp', 'mp4'])) {
            $compressedImage = InterventionImage::make($image);

            $compressedImage->encode('png', 65);
            $imageName = time() . '_' . rand(1, 99) . '.png';

            $path = public_path('uploads/' . $imageName);

            $compressedImage->save($path);

            // Get the size of the image
            $imageSize = round($compressedImage->filesize() / 1024, 2);

            // Save the image data in the database
            $imageModel = new Image(); // Use the actual model name
            $imageModel->file_name = $imageName;
            $imageModel->size = $imageSize;
            $imageModel->save();

            return response()->json(['success' => $imageName]);
        } else {
            // Return error response if the uploaded file is not an image
            return response()->json(['error' => 'Invalid image file.'], 400);
        }
    }

    // public function upload_icon(Request $request)
    // {
    //     $icon = $request->file('file');

    //     // Check if the file is an icon
    //     if ($icon->isValid() && in_array($icon->getClientOriginalExtension(), ['jpeg', 'jpg', 'png', 'gif', 'webp', 'mp4'])) {
    //         $compressedIcon = InterventionImage::make($icon);

    //         $compressedIcon->encode('png', 65);
    //         $iconName = time() . '_' . rand(1, 99) . '.png';

    //         $path = public_path('uploads/' . $iconName);

    //         $compressedIcon->save($path);

    //         // Get the size of the icon
    //         $iconSize = round($compressedIcon->filesize() / 1024, 2);

    //         // Save the icon data in the database
    //         $iconModel = new Icon(); // Use the actual model name
    //         $iconModel->file_name = $iconName;
    //         $iconModel->size = $iconSize;
    //         $iconModel->save();

    //         return response()->json(['success' => $iconName]);
    //     } else {
    //         // Return error response if the uploaded file is not an icon
    //         return response()->json(['error' => 'Invalid icon file.'], 400);
    //     }
    // }

    public function get_images()
    {
        $images = Image::select('*')->orderBy('created_at', 'desc')->paginate(8);
        
        return response()->json($images);
    }

    public function editor_upload_image(Request $request) // Add the $request parameter here
    {
        $uploadedImage = $request->file('file');
        $imageName = time() . '.' . $uploadedImage->getClientOriginalExtension();
        $destinationPath = public_path('uploads/editor');

        $uploadedImage->move($destinationPath, $imageName);

        // $imageUrl = url('public/uploads/editor/' . $imageName); // Use url() instead of asset()
        $imageUrl = env('APP_URL') . '/public/uploads/editor/' . $imageName;

        return response()->json(['url' => $imageUrl]); // Return JSON response with a key 'url'
    }

    public function delete_image(Request $request)
    {
        $image = Image::find($request->id);

        // Check if the image record exists
        if (!$image) {
            return response()->json(['error' => 'Image not found.'], 404);
        }

        // Delete the file from the uploads directory
        $filePath = public_path('uploads/' . $image->file_name);
        if (file_exists($filePath)) {
            unlink($filePath); // Delete the file
        }

        // Delete the image record from the database
        $image->delete();

        return response()->json(['success' => 'Image deleted successfully.']);
    }
}
