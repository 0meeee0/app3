<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\Content;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Password;

class LoginController extends Controller
{

    public function show()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.auth.login', ['settings' => $settings, 'index_text' => $index_text]);
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials, $request->input('remember'))) {
            $request->session()->regenerate();

            return redirect()->route('home');
        }

        return back()->withErrors([
            'email' => 'Les informations sont inccorect !',
        ]);
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/login');
    }
}
