<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Blog_category;
use Illuminate\Http\Request;
use App\Models\Setting;
use App\Models\Content;

class BlogController extends Controller
{
    public function index(Request $request)
    {
        if ($request->has('search')) {
            $blogs = Blog::select('*')
                ->join('blog_categories', 'blogs.category_id', '=', 'blog_categories.id')
                ->where('blogs.title', 'like', '%' . $request->input('search') . '%')
                ->whereOr('blogs.description', 'like', '%' . $request->input('search') . '%')
                ->whereOr('blogs.content', 'like', '%' . $request->input('search') . '%')
                ->whereOr('blog_categories.title', 'like', '%' . $request->input('search') . '%')
                ->get();
        } else {
            $blogs = Blog::all();
        }

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blog.index', [
            'blogs' => $blogs,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function create()
    {
        $categories = Blog_category::all();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blog.create', [
            'categories' => $categories,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'category_id' => 'required',
            'description' => 'required',
            'selecteImages' => 'required',
            'content' => 'required',
        ]);

        $blog = new Blog();
        $blog->title = $data['title'];
        $blog->category_id = $data['category_id'];
        $blog->description = $data['description'];
        $blog->banner_id = $data['selecteImages'];
        $blog->content = $data['content'];

        if ($blog->save()) {
            return redirect()->back()->with('success', 'Blog ajouté avec succès');
        } else {
            return redirect()->back()->with('error', 'Blog n\'est pas ajouté ! essayer à nouveau.');
        }
    }

    public function show(Blog $blog)
    {
        //
    }

    public function edit($id)
    {
        $categories = Blog_category::all();
        $blog = Blog::findOrFail($id);
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.blog.edit', [
            'categories' => $categories,
            'blog' => $blog,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function update(Request $request, Blog $blog)
    {
        $data = $request->validate([
            'title' => 'required',
            'category_id' => 'required',
            'description' => 'required',
            'selecteImages' => 'required',
            'content' => 'required',
        ]);

        $blog->title = $data['title'];
        $blog->category_id = $data['category_id'];
        $blog->description = $data['description'];
        $blog->banner_id = $data['selecteImages'];
        $blog->content = $data['content'];

        if ($blog->save()) {
            return redirect()->back()->with('success', 'Blog modifié avec succès');
        } else {
            return redirect()->back()->with('error', 'Blog n\'est pas modifié ! essayer à nouveau.');
        }
    }

    public function destroy(Blog $blog)
    {
        if ($blog->delete()) {
            return redirect()->back()->with('success', 'Blog supprimé avec succès');
        } else {
            return redirect()->back()->with('error', 'Blog n\'est pas supprimé ! essayer à nouveau.');
        }
    }
}
