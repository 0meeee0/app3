<?php

namespace App\Http\Controllers;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

use App\Mail\ContactEmail;
use App\Mail\DevisEmail;
use App\Mail\RappelEmail;
use App\Models\contact_info;
use App\Models\Setting;
use App\Models\Content;
use App\Models\Contact;
use App\Models\Devis;
use Illuminate\Support\Facades\Mail;

use Illuminate\Support\Facades\Log;

class EmailController extends Controller
{
    public function sendContactEmail(Request $request)
    {
        // Validate the request data if needed
        $data = $request->validate([
            'email' => 'required|email',
            'name' => 'required',
            'phone' => 'required',
            'subject' => 'required',
            'message' => 'required',
        ]);

        $email_contact = Content::select('*')->where('type', '=', 'contact_page')->first();

        // Get the data from the request
        $recipientEmail = $data['email'];
        $name = $data['name'];
        $phone = $data['phone'];
        $subject = $data['subject'];
        $message = $data['message'];

        try {
            // Send the email using the ContactEmail Mailable class
            Mail::to($email_contact['email'])->send(new ContactEmail($name, $recipientEmail, $phone, $subject, $message));

            // Save the contact data to the database
            $contact = new Contact();
            $contact->name = $name;
            $contact->email = $recipientEmail;
            $contact->phone = $phone;
            $contact->subject = $subject;
            $contact->message = $message;
            $contact->save();

            // Email sent successfully
            return redirect()->back()->with('success', 'Message envoyé avec succès.');
        } catch (\Exception $e) {
            // Handle any errors that occurred during email sending
            // return response()->json(['message' => 'Error sending email'], 500);
            // return $e->getMessage();
            return redirect()->back()->with('error', 'Message n\'est pas envoyé ! Essayer à nouveau.');
        }
    }

    public function sendDevisEmail(Request $request)
    {
        // Validate the request data if needed
        $data = $request->validate([
            'societe' => '',
            'email' => 'required|email',
            'phone' => 'required',
            'adresse' => '',
            'zipcode' => '',
            'city' => '',
            'demande' => 'required',
        ]);

        $email_devis = Content::select('*')->where('type', '=', 'devis_page')->first();

        // Get the data from the request
        $societe = $data['societe'];
        $email = $data['email'];
        $phone = $data['phone'];
        $adress = $data['adresse'];
        $code_postale = $data['zipcode'];
        $ville = $data['city'];
        $demande = $data['demande'];

        try {
            // Send the email using the ContactEmail Mailable class
            Mail::to($email_devis['email'])->send(new DevisEmail($societe, $email, $phone, $adress, $code_postale, $ville, $demande));

            $devisData = new Devis();
            $devisData->societe = $societe;
            $devisData->email = $email;
            $devisData->phone = $phone;
            $devisData->adress = $adress;
            $devisData->codePostal = $code_postale; // Corrected column name
            $devisData->ville = $ville;
            $devisData->demande = $demande;
            $devisData->save();

            // Email sent successfully
            return redirect()->back()->with('success', 'Demande envoyé avec succès');
            // return response()->json($devisData);
        } catch (\Exception $e) {
            // Handle any errors that occurred during email sending
            // return response()->json(['message' => 'Error sending email'], 500);
            // return $e->getMessage();
            return redirect()->back()->with('error', 'Demande n\'est pas envoyé ! essayer à nouveau.');
        }
    }

    public function devis_list(Request $request)
    {
        if ($request->has('search')) {
            $searchTerm = $request->input('search');

            $devis = Devis::where(function ($query) use ($searchTerm) {
                $query->where('societe', 'like', '%' . $searchTerm . '%')
                    ->orWhere('email', 'like', '%' . $searchTerm . '%')
                    ->orWhere('phone', 'like', '%' . $searchTerm . '%')
                    ->orWhere('adress', 'like', '%' . $searchTerm . '%')
                    ->orWhere('codePostal', 'like', '%' . $searchTerm . '%')
                    ->orWhere('ville', 'like', '%' . $searchTerm . '%')
                    ->orWhere('demande', 'like', '%' . $searchTerm . '%');
            })->get();
        } else {
            $devis = Devis::all();
        }

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.emails.devisList', compact('devis', 'index_text', 'settings'));
    }

    public function devis_show($id)
    {
        $devis = Devis::find($id);
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.emails.devisShow', compact('devis', 'index_text', 'settings'));
    }

    public function contact_list(Request $request)
    {
        if ($request->has('search')) {
            $searchTerm = $request->input('search');

            $contact = Contact::where(function ($query) use ($searchTerm) {
                $query->where('name', 'like', '%' . $searchTerm . '%')
                    ->orWhere('email', 'like', '%' . $searchTerm . '%')
                    ->orWhere('phone', 'like', '%' . $searchTerm . '%')
                    ->orWhere('subject', 'like', '%' . $searchTerm . '%')
                    ->orWhere('message', 'like', '%' . $searchTerm . '%');
            })->get();
        } else {
            $contact = Contact::all();
        }

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.emails.contactList', compact('contact', 'index_text', 'settings'));
    }

    public function contact_show($id)
    {
        $contact = Contact::find($id);
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.emails.contactShow', compact('contact', 'index_text', 'settings'));
    }
    public function devis_delete($id)
    {
        Devis::destroy($id);
        return redirect()->back()->with('success', 'Email a été supprimé avec succès !');
    }
    public function contact_delete($id)
    {
        Contact::destroy($id);
        return redirect()->back()->with('success', 'Email a été supprimé avec succès !');
    }
}
