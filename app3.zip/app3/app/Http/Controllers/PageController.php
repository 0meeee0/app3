<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index(string $page)
    {
        if (view()->exists("administration.pages.{$page}")) {
            return view("administration.pages.{$page}");
        }

        return abort(404);
    }

    
    public function main(string $main)
    {
        if (view()->exists("client.{$main}")) {
            return view("client.{$main}");
        }
        return abort(404);
    }



    public function profile()
    {
        return view("administration.pages.profile-static");
    }

    public function signin()
    {
        return view("administration.pages.sign-in-static");
    }

    public function signup()
    {
        return view("administration.pages.sign-up-static");
    }
}
