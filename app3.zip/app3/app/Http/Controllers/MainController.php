<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Category;
use \App\Models\Article;
use \App\Models\Image;
use \App\Models\Collection;
use \App\Models\Project;
use \App\Models\Images;
use \App\Models\Propose;
use \App\Models\services;
use \App\Models\Content;
use \App\Models\Project_images;
use \App\Models\ProjectCategory;
use \App\Models\Setting;
use \App\Models\Blog;
use \App\Models\Blog_category;

class MainController extends Controller
{
    public function index(Request $request)
    {
        $about_us = Content::select('*')->where('type', '=', 'about_us')->first();
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $home_video = Content::select('*')->where('type', '=', 'home_video')->first();
        $contact_page = Content::select('*')->where('type', '=', 'contact_page')->first();
        $devis_page = Content::select('*')->where('type', '=', 'devis_page')->first();
        $services_page = Content::select('*')->where('type', '=', 'services_page')->first();
        $services = services::all();
        
        $portfolio_page = Content::select('*')->where('type', '=', 'portfolio_page')->first();
        $ProjectCategory = ProjectCategory::all();
        $projects = Project::get_all_published();

        $settings = Setting::findOrFail(1);
    
        $blogs = Blog::all();
        $blogs_cat = Blog_category::all();

        $about_img = Image::findOrFail($about_us->image_id);
        $about_us->file_name = $about_img['file_name'];

        return view('Front.pages.home_page', [
            'about_us' => $about_us,
            'index_text' => $index_text,
            // 'portfolio_page' => $portfolio_page,
            // 'projects' => $projects,
            // 'contact_page' => $contact_page,
            // 'devis_page' => $devis_page,
            // 'services_page' => $services_page,
            // 'services' => $services,
            // 'ProjectCategory' => $ProjectCategory,
            'home_video' => $home_video,
            'settings' => $settings,
            // 'blogs' => $blogs,
            // 'blogs_cat' => $blogs_cat,
        ]);
    }

    public function show_category($slug)
    {
        $category = Category::select('categories.*', 'images.file_name')
            ->join('images', 'categories.banner_id', '=', 'images.id')
            ->where('categories.slug', '=', $slug)
            ->first();

        if ($category == null) {
            abort(404);
        }

        if ($category->publish == 0) {
            abort(404);
        }

        $articles = Article::select('articles.*', 'images.file_name')
            ->where('category_id', '=', $category->id)
            ->join('images', 'articles.image_id', '=', 'images.id')
            ->get();

        return view('client.category', [
            'category' => $category,
            'articles' => $articles,
        ]);
    }
    
    public function show_article($category, $slug)
    {
        $category = Category::select('*')->where('slug', '=', $category)->first();

        if ($category == null) {
            abort(404);
        }else {

            if ($category->publish == 0) {
                abort(404);
            }
    
            $article = Article::select('articles.*', 'images.file_name')
                ->join('images', 'articles.image_id', '=', 'images.id')
                ->where('articles.slug', '=', $slug)
                ->where('articles.category_id', '=', $category->id)
                ->first();
            
            if ($article == null) {
                abort(404);
            }else{

                if ($article->publish == 0) {
                    abort(404);
                }
        
                $images = Image::select('images.*')->join('article_images', 'images.id', '=', 'article_images.image_id')
                    ->where('article_images.article_id', '=', $article->id)
                    ->get();
        
                $articles = Article::get_all_by_category($category->id);
        
                return view('client.article', [
                    'article' => $article,
                    'category' => $category,
                    'images' => $images,
                    'articles' => $articles,
                ]);
            }
        }

        
    }

    public function show_blog(Blog $blog)
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
            
        $blogs = Blog::where('category_id', '=', $blog->category_id)->get();

        return view('Front.index', [
            'settings' => $settings,
            'index_text' => $index_text,
            'blog' => $blog,
            'blogs' => $blogs,
        ]);
    }
    public function show_portfolio(Project $project)
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
            
        $projects = Project::where('category_id', '=', $project->category_id)->get();
        
        return view('Front.index', [
            'settings' => $settings,
            'index_text' => $index_text,
            'project' => $project,
            'projects' => $projects,
        ]);
    }
    
    public function show_service(services $service)
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
            
        $services = services::all();
        
        return view('Front.index', [
            'settings' => $settings,
            'index_text' => $index_text,
            'service' => $service,
            'services' => $services,
        ]);
    }
    
    public function about_page()
    {
        $about_us = Content::select('*')->where('type', '=', 'about_us')->first();
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        $settings = Setting::findOrFail(1);

        $about_img = Image::findOrFail($about_us->image_id);
        $about_us->file_name = $about_img['file_name'];

        return view('Front.pages.about_page', [
            'about_us' => $about_us,
            'index_text' => $index_text,
            'settings' => $settings,
        ]);
    }

    public function service_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);

        $services_page = Content::select('*')->where('type', '=', 'services_page')->first();
        $services = services::all();


        return view('Front.pages.service_page', [
            'index_text' => $index_text,
            'services_page' => $services_page,
            'services' => $services,
            'settings' => $settings,
        ]);
    }

    public function potfolio_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);

        $portfolio_page = Content::select('*')->where('type', '=', 'portfolio_page')->first();
        $ProjectCategory = ProjectCategory::all();
        $projects = Project::get_all_published();


        return view('Front.pages.portfolio_page', [
            'index_text' => $index_text,
            'settings' => $settings,
            'portfolio_page' => $portfolio_page,
            'ProjectCategory' => $ProjectCategory,
            'projects' => $projects,
        ]);
    }

    public function contact_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);
        
        $contact_page = Content::select('*')->where('type', '=', 'contact_page')->first();

        return view('Front.pages.contact_page', [
            'index_text' => $index_text,
            'settings' => $settings,
            'contact_page' => $contact_page,
        ]);
    }

    public function blog_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);
        
        $blogs = Blog::all();
        $blogs_cat = Blog_category::all();

        return view('Front.pages.blog_page', [
            'index_text' => $index_text,
            'settings' => $settings,
            'blogs' => $blogs,
            'blogs_cat' => $blogs_cat,
        ]);
    }

    public function devis_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);
        $devis_page = Content::select('*')->where('type', '=', 'devis_page')->first();
        
        return view('Front.pages.devis_page', [
            'index_text' => $index_text,
            'settings' => $settings,
            'devis_page' => $devis_page,
        ]);
    }
}
