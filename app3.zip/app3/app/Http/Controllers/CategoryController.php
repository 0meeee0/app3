<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::select('categories.*' , 'images.file_name')
            ->join('images', 'categories.banner_id', '=', 'images.id')
            ->paginate(5);


        return view('administration.pages.categories.index',[
            'categories' => $categories,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('administration.pages.categories.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => '',
            'description' => '',
            'selecteImages' => '',
            'publie' => '',
        ]);

        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($data['title']));

        $count = 1;
        while (Category::isSlugExists($slug)) {
            $slug = $slug . '-' . $count;
            $count++;
        }

        $category = new Category();
        $category->title = $data['title'];
        $category->short_description = $data['short_description'];
        $category->description = $data['description'];
        $category->banner_id = $data['selecteImages'];
        $category->slug = $slug;

        if (isset($data['publie']) && $data['publie'] == '1') {
            $category->publish = '1';
        }else {
            $category->publish = '0 '; 
        }

        if ($category->save()) {
            return redirect()->back()->with('success', 'Catégorie ajouté avec succès');
        }

        return redirect()->back()->with('error', 'Catégorie n\'est pas ajouté ! essayer à nouveau.');

    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $category = Category::findOrFail($id);
        return view('administration.pages.categories.edit', [
            'category' => $category,
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => '',
            'description' => '',
            'selecteImages' => '',
            'publie' => '',
        ]);

        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($data['title']));

        $count = 1;
        while (Category::isSlugExists($slug)) {
            $slug = $slug . '-' . $count;
            $count++;
        }

        $category = Category::findOrFail($id);
        $category->title = $data['title'];
        $category->short_description = $data['short_description'];
        $category->description = $data['description'];
        $category->banner_id = $data['selecteImages'];
        $category->slug = $slug;

        if (isset($data['publie']) && $data['publie'] == '1') {
            $category->publish = '1';
        }else {
            $category->publish = '0 '; 
        }

        if ($category->save()) {
            return redirect()->back()->with('success', 'Catégorie modifié avec succès');
        }

        return redirect()->back()->with('error', 'Catégorie n\'est pas modifié ! essayer à nouveau.');
    }

    public function destroy($id)
    {
        //
    }
}
