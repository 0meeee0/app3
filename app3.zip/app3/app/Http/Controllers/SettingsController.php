<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Setting;
use \App\Models\Content;

class SettingsController extends Controller
{
    public function settings_pages()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.settings.pages', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function email_pages()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.settings.email', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function settings_pages_update(Request $request)
    {
        $settings = Setting::firstOrNew(['id' => 1]);

        try {
            $settings->is_about_section = $request->has('about_page');
            $settings->is_service_section = $request->has('service_page');
            $settings->is_portfolio_section = $request->has('portfolio_page');
            $settings->is_contact_section = $request->has('contact_page');
            $settings->is_blog_section = $request->has('blog_page');
            $settings->is_devis_section = $request->has('devis_page');

            if ($settings->save()) {
                return redirect()->back()->with('success', 'Page modifié avec succès');
            } else {
                return redirect()->back()->with('error', 'Page n\'est pas modifié ! essayer à nouveau.');
            }
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }

    public function settings_colors()
    {
        $settings = Setting::firstOrNew(['id' => 1]);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.settings.colors', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function settings_colors_update(Request $request)
    {
        $data = $request->validate([
            'back_color' => 'required',
            'primary_color' => 'required',
        ]);
        $settings = Setting::firstOrNew(['id' => 1]);

        try {
            $settings->back_color = $data['back_color'];
            $settings->primary_color = $data['primary_color'];

            $settings->save();

            return redirect()->back()->with('success', 'Page modifié avec succès');
        } catch (\Throwable $th) {
            return redirect()->back()->with('error', 'Page n\'est pas modifié ! essayer à nouveau.');
        }
    }
}
