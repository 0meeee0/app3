<?php

namespace App\Http\Controllers;

use App\Models\Devis;
use App\Models\Contact;
use App\Models\services;
use App\Models\Blog;
use App\Models\Setting;
use App\Models\Content;
use Illuminate\Http\Request;


class HomeController extends Controller
{
    public function index()
    {
        $numberOfDevis = Devis::count();
        $numberOfContact = Contact::count();
        $numberOfServices = Services::count();
        $numbreOfBlog = Blog::count();
        $latestDevis = Devis::latest()->take(12)->get();
        $latestContact = Contact::latest()->take(8)->get();

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.dashboard', compact('numberOfDevis', 'numberOfContact', 'numberOfServices', 'numbreOfBlog', 'latestDevis', 'latestContact', 'settings', 'index_text'));
    }
}
