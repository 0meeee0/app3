<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Collection;
use App\Models\Collection_image;
use App\Models\Setting;
use App\Models\Content;

class CollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $collections = Collection::select('*')->get();
        return view('administration.pages.collection.index', [
            'collections' => $collections,
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.collection.create', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'short_description' => 'required'
        ]);

        $collection = new Collection();
        $collection->title = $data['title'];
        $collection->description = $data['description'];
        $collection->short_description = $data['short_description'];

        if ($collection->save()) {
            return redirect()->back()->with('success', 'Collection ajouté avec succès');
        }

        return redirect()->back()->with('error', 'Collection n\'est pas ajouté ! essayer à nouveau.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $collection = Collection::findOrFail($id);
        return view('administration.pages.collection.edit', [
            'collection' => $collection,
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => 'required',
            'description' => 'required',
            'selecteImages' => 'required',
        ]);

        $collection = Collection::findOrFail($id);
        $collection->title = $data['title'];
        $collection->description = $data['description'];
        $collection->short_description = $data['short_description'];
        $collection->banner_id = $data['selecteImages'];

        if ($collection->save()) {
            return redirect()->back()->with('success', 'Collection modifié avec succès');
        }

        return redirect()->back()->with('error', 'Collection n\'est pas modifié ! essayer à nouveau.');
    }

    public function destroy($id)
    {
        $collection = Collection::findOrFail($id);
        try {

            if ($collection->destroy($id)) {
                return redirect()->back()->with('success', 'Collection a été supprimé avec succès');
            }

            return redirect()->back()->with('error', 'Collection n\'est pas supprimé ! essayer à nouveau.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Collection n\'est pas supprimé ! essayer à nouveau.');
        }
    }

    public function images_index($id)
    {
        $collection = Collection::findOrFail($id);
        $images = Collection_image::select('images.*')->join('images', 'collection_images.image_id', '=', 'images.id')->where('collection_images.collection_id', '=', $id)->get();
        return view('administration.pages.collection.add_images', [
            'images' => $images,
            'collection' => $collection,
        ]);
    }

    public function add_collection_images(Request $request, $id)
    {
        $images = $request->input('images');
        foreach ($images as $img_id) {
            Collection_image::create(['collection_id' => $id, 'image_id' => $img_id]);
        }

        $images_collection = Collection_image::select('images.*')->join('images', 'collection_images.image_id', '=', 'images.id')->where('collection_images.collection_id', '=', $id)->get();
        return response()->json($images_collection);
    }
    public function remove_image_collection($id)
    {
        $image = Collection_image::where('image_id', '=', $id)->firstOrFail();
        if ($image->deleteWithImageId()) {
            return redirect()->back()->with('success', 'Image a été supprimé avec succès');
        }
        return redirect()->back()->with('error', 'Image n\'est pas supprimé ! essayer à nouveau.');
    }
    public function get_collection_images($id)
    {
        $images = Collection_image::select('images.*')->join('images', 'collection_images.image_id', '=', 'images.id')->where('collection_images.collection_id', '=', $id)->get();
        return response()->json($images);
    }
}
