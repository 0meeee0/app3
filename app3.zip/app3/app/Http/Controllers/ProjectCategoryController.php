<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\ProjectCategory;
use App\Models\Setting;
use App\Models\Content;

class ProjectCategoryController extends Controller
{
    public function index()
    {
        $categories = ProjectCategory::all();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.projectCategory.index', [
            'categories' => $categories,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function create()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.projectCategory.create', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);

        $categorie = new ProjectCategory();
        $categorie->name = $data['title'];
        $categorie->description = $data['description'];

        if ($categorie->save()) {
            return redirect()->back()->with('success', 'Catégorie ajouté avec succès');
        }
        return redirect()->back()->with('error', 'Catégorie n\'est pas ajouté ! essayer à nouveau.');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $category = ProjectCategory::findOrFail($id);
        return view('administration.pages.projectCategory.edit', [
            'category' => $category,
        ]);
    }

    public function update(Request $request, $id)
    {
        $categorie = ProjectCategory::findOrFail($id);

        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);

        $categorie->name = $data['title'];
        $categorie->description = $data['description'];

        if ($categorie->save()) {
            return redirect()->back()->with('success', 'Catégorie modifié avec succès');
        }
        return redirect()->back()->with('error', 'Catégorie n\'est pas modifié ! essayer à nouveau.');
    }

    public function destroy($id)
    {
        $category = ProjectCategory::findOrFail($id);

        if ($category->delete()) {
            return redirect()->back()->with('success', 'Catégorie supprimé avec succès');
        }
        return redirect()->back()->with('error', 'Catégorie n\'est pas supprimé ! essayer à nouveau.');
    }
}
