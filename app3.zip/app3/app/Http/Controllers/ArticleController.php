<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Article;

class ArticleController extends Controller
{
    public function index()
    {
        $articles = Article::select('articles.*', 'images.file_name')
            ->join('images', 'articles.image_id', '=', 'images.id')
            ->get();

        return view('administration.pages.articles.index', [
            'articles' => $articles,
        ]);
    }

    public function create()
    {
        return view('administration.pages.articles.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => '',
            'description' => '',
            'selecteImages' => '',
            'publie' => '',
            'category_id' => 'required',
        ]);

        $slug = preg_replace('/[^a-z0-9]+/', '-', strtolower($data['title']));

        $count = 1;
        while (Article::isSlugExists($slug)) {
            $slug = $slug . '-' . $count;
            $count++;
        }

        $article = new Article();
        $article->title = $data['title'];
        $article->short_description = $data['short_description'];
        $article->description = $data['description'];
        $article->image_id = $data['selecteImages'];
        $article->category_id = $data['category_id'];
        $article->slug = $slug;

        if (isset($data['publie']) && $data['publie'] == '1') {
            $article->publish = '1';
        }else {
            $article->publish = '0 '; 
        }

        if ($article->save()) {
            return redirect()->back()->with('success', 'Article ajouté avec succès');
        }

        return redirect()->back()->with('error', 'Article n\'est pas ajouté ! essayer à nouveau.');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $article = Article::findOrFail($id);
        return view('administration.pages.articles.edit', [
            'article' => $article,
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => '',
            'description' => '',
            'selecteImages' => '',
            'publie' => '',
        ]);


        $article = Article::findOrFail($id);
        $article->title = $data['title'];
        $article->short_description = $data['short_description'];
        $article->description = $data['description'];
        $article->image_id = $data['selecteImages'];

        if (isset($data['publie']) && $data['publie'] == '1') {
            $article->publish = '1';
        }else {
            $article->publish = '0 '; 
        }

        if ($article->save()) {
            return redirect()->back()->with('success', 'Article modifié avec succès');
        }

        return redirect()->back()->with('error', 'Article n\'est pas modifié ! essayer à nouveau.');
    }

    public function destroy($id)
    {
        $article = Article::findOrFail($id);
        try {

            if ($article->destroy($id)) {
                return redirect()->back()->with('success', 'Article a été supprimé avec succès');
            }
    
            return redirect()->back()->with('error', 'Article n\'est pas supprimé ! essayer à nouveau.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Article n\'est pas supprimé ! essayer à nouveau.');
        }
    }
}
