<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\contact_info;
use \App\Models\Content;
use \App\Models\SocialMedia;
use \App\Models\Propose;
use \App\Models\Setting;
use \App\Models\Partners;

class ContentController extends Controller
{
    public function index()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        $about_us = Content::select('*')->where('type', '=', 'about_us')->first();
        $portfolio_page = Content::select('*')->where('type', '=', 'portfolio_page')->first();
        $contact_page = Content::select('*')->where('type', '=', 'contact_page')->first();
        $devis_page = Content::select('*')->where('type', '=', 'devis_page')->first();

        return view('administration.pages.content', [
            'index_text' => $index_text,
            'about_us' => $about_us,
            'portfolio_page' => $portfolio_page,
            'contact_page' => $contact_page,
            'devis_page' => $devis_page,
        ]);
    }

    public function home_page()
    {
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();
        $settings = Setting::findOrFail(1);

        return view('administration.pages.content.home', [
            'index_text' => $index_text,
            'settings' => $settings,
        ]);
    }
    public function social_media_edit()
    {
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.content.socialMedia', [
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }
    public function contact_edit()
    {
        $contact_page = Content::select('*')->where('type', '=', 'contact_page')->first();
        $devis_page = Content::select('*')->where('type', '=', 'devis_page')->first();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();


        return view('administration.pages.content.contact', [
            'contact_page' => $contact_page,
            'devis_page' => $devis_page,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }
    public function about_page_edit()
    {
        $about_us = Content::select('*')->where('type', '=', 'about_us')->first();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.content.about', [
            'about_us' => $about_us,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function partners_edit()
    {
        $partners = Partners::all();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.content.partners', compact('partners', 'settings', 'index_text'));
    }
    public function partners_delete(Partners $partners)
    {
        $partners->delete();
        return redirect()->back()->with('success', 'Partenaire supprimé avec succès');
    }

    public function partners_update(Request $request)
    {

        try {
            $partner = new Partners;
            $partner->name = $request->input('name');
            $partner->description = $request->input('description');

            $imageFile = $request->file('image');
            $imageName = time() . '_' . $imageFile->getClientOriginalName();

            // Move the uploaded image to the desired directory
            $imagePath = $imageFile->move(public_path('assets/img/partners'), $imageName);

            $partner->image = $imageName;
            $partner->save();

            return redirect()->back()->with('success', 'Les informations modifié avec succès');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }

    public static function get_contact_info()
    {
        $contact = contact_info::select('*')->get();
        return $contact;
    }
    public static function get_contact_info_by_name($name)
    {
        $contact_info = contact_info::select('*')->where('name', '=', $name)->first();
        return $contact_info['content'];
    }

    public static function get_content_by_type($type)
    {
        return Content::select('title', 'description')->where('type', '=', $type)->first();
    }




    public function info_generale_update(Request $request)
    {
        try {
            $infos = $request->input('info');

            // Loop through the form inputs and update or insert each value based on the custom key
            foreach ($infos as $key => $value) {
                contact_info::updateOrCreate(
                    ['name' => $key], // name column in the table
                    ['content' => $value] // content to be inserted/updated
                );
            }

            return redirect()->back()->with('success', 'Les informations modifié avec succès');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        }
    }

    public function collection_content_update(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);

        $content = Content::where('type', '=', 'collection_index')->firstOrFail();
        $content->title = $data['title'];
        $content->description = $data['description'];
        if ($content->save()) {
            return redirect()->back()->with('success', 'Collection modifié avec succès');
        } else {
            return redirect()->back()->with('error', 'Collection n\'est pas modifié ! essayer à nouveau.');
        }
    }

    public function social_media_update(Request $request)
    {
        try {
            $links = $request->input('social');

            foreach ($links as $key => $value) {
                SocialMedia::updateOrCreate(
                    ['name' => $key],
                    ['link' => $value]
                );
            }
            return redirect()->back()->with('success', 'Les informations modifié avec succès');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        }
    }

    public function footer_update(Request $request)
    {
        try {
            $texts = $request->input('content');
            foreach ($texts as $key => $value) {
                Content::updateOrCreate(
                    ['type' => $key],
                    ['description' => $value]
                );
            }

            return redirect()->back()->with('success', 'Les informations modifié avec succès');
        } catch (\Exception $th) {
            /* return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.'); */
            return $th->getMessage();
        }
    }

    public function about_us_update(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'content' => 'required',
            'selecteImages' => 'required',
        ]);
        try {
            $about_us = Content::where('type', '=', 'about_us')->firstOrFail();
            $about_us->title = $data['title'];
            $about_us->description = $data['description'];
            $about_us->content = $data['content'];
            $about_us->image_id = $data['selecteImages'];

            if ($about_us->save()) {
                return redirect()->back()->with('success', 'Les informations modifié avec succès');
            }
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }

    public function index_text_update(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'description' => 'required',
        ]);
        try {
            $index_text = Content::where('type', '=', 'index_text')->firstOrFail();
            $settings = Setting::firstOrNew(['id' => 1]);

            $settings->site_title = $data['title'];
            $index_text->title = $data['title'];
            $index_text->description = $data['description'];

            if ($index_text->save() && $settings->save()) {
                return redirect()->back()->with('success', 'Les informations modifié avec succès');
            }
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }
    public function contact_update(Request $request)
    {
        $data = $request->validate([
            'contact_title' => 'required',
            'contact_email' => 'required',
        ]);
        try {
            $contact_page = Content::where('type', '=', 'contact_page')->firstOrFail();

            $contact_page->title = $data['contact_title'];
            $contact_page->email = $data['contact_email'];

            if ($contact_page->save()) {
                return redirect()->back()->with('success', 'Les informations modifié avec succès');
            }
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }
    public function devis_update(Request $request)
    {
        $data = $request->validate([
            'devis_title' => 'required',
            'devis_email' => 'required',
        ]);
        try {
            $devis_page = Content::where('type', '=', 'devis_page')->firstOrFail();

            $devis_page->title = $data['devis_title'];
            $devis_page->email = $data['devis_email'];

            if ($devis_page->save()) {
                return redirect()->back()->with('success', 'Les informations modifié avec succès');
            }
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }
    public function media_update(Request $request)
    {
        $request->validate([
            'title_1' => 'required',
            'title_2' => 'required',
            'title_3' => 'required',
        ]);

        try {
            $index_text = Content::where('type', '=', 'index_text')->firstOrFail();
            $home_slide_1 = Content::where('type', '=', 'home_slide_1')->firstOrFail();
            $home_slide_2 = Content::where('type', '=', 'home_slide_2')->firstOrFail();
            $home_slide_3 = Content::where('type', '=', 'home_slide_3')->firstOrFail();
            $settings = Setting::firstOrNew(['id' => 1]);

            $slide_1 = $request->file('slide_1');
            if ($slide_1) {
                $filename = 'mega-crafters_' . $slide_1->getClientOriginalName();
                $slide_1->move(public_path('assets/img/video'), $filename);
                $home_slide_1->content = $filename;
            }

            $slide_2 = $request->file('slide_2');
            if ($slide_2) {
                $filename = 'mega-crafters_' . $slide_2->getClientOriginalName();
                $slide_2->move(public_path('assets/img/video'), $filename);
                $home_slide_2->content = $filename;
            }

            $slide_3 = $request->file('slide_3');
            if ($slide_3) {
                $filename = 'mega-crafters_' . $slide_3->getClientOriginalName();
                $slide_3->move(public_path('assets/img/video'), $filename);
                $home_slide_3->content = $filename;
            }

            $logo = $request->input('selecteImages');

            if ($logo) {
                $index_text->image_id = $request->input('selecteImages');
            }

            $icon = $request->file('icon');
            if ($icon) {
                $filename = 'favicon_' . $icon->getClientOriginalName();
                $icon->move(public_path('assets/img/favicon'), $filename);
                $settings->favicon = $filename;
            }

            $home_slide_1->title = $request->input('title_1');
            $home_slide_2->title = $request->input('title_2');
            $home_slide_3->title = $request->input('title_3');

            if ($index_text->save() && $home_slide_1->save() && $home_slide_2->save() && $home_slide_3->save() && $settings->save()) {
                return redirect()->back()->with('success', 'Les informations modifié avec succès');
            }
            return redirect()->back()->with('error', 'Les informations n\'est pas modifié ! essayer à nouveau.');
        } catch (\Exception $th) {
            return $th->getMessage();
        }
    }
}
