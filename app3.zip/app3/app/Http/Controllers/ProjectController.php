<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Project;
use \App\Models\Images;
use \App\Models\Project_images;
use \App\Models\ProjectCategory;
use App\Models\Setting;
use App\Models\Content;

class ProjectController extends Controller
{
    public function index(Request $request)
    {
        if ($request->has('search')) {
            $projects = Project::select('projects.*', 'images.file_name')
                ->join('images', 'projects.banner_id', '=', 'images.id')
                ->join('project_categories', 'projects.category_id', '=', 'project_categories.id')
                ->where('projects.titre', 'like', '%' . $request->input('search') . '%')
                ->whereOr('projects.description', 'like', '%' . $request->input('search') . '%')
                ->whereOr('projects.content', 'like', '%' . $request->input('search') . '%')
                ->whereOr('project_categories.name', 'like', '%' . $request->input('search') . '%')
                ->get();
        } else {
            $projects = Project::select('projects.*', 'images.file_name')
                ->join('images', 'projects.banner_id', '=', 'images.id')
                ->get();
        }

        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.project.index', [
            'projects' => $projects,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function create()
    {
        $category = ProjectCategory::all();
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.project.create', [
            'category' => $category,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }


    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => 'required',
            'description' => 'required',
            'content' => 'required',
            'category_id' => '',
            'selecteImages' => '',
        ]);

        $project = new Project();
        $project->titre = $data['title'];
        $project->short_description = $data['short_description'];
        $project->description = $data['description'];
        $project->content = $data['content'];
        $project->category_id = $data['category_id'];
        $project->banner_id = $data['selecteImages'];

        if ($project->save()) {
            return redirect()->back()->with('success', 'Portfolio ajouté avec succès');
        }

        return redirect()->back()->with('error', 'Portfolio n\'est pas ajouté ! essayer à nouveau.');
    }

    public function show($id)
    {
    }

    public function edit($id)
    {
        $project = Project::findOrFail($id);
        $settings = Setting::findOrFail(1);
        $index_text = Content::select('contents.*', 'images.file_name')
            ->join('images', 'contents.image_id', '=', 'images.id')
            ->where('type', '=', 'index_text')
            ->first();

        return view('administration.pages.project.edit', [
            'project' => $project,
            'settings' => $settings,
            'index_text' => $index_text,
        ]);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'title' => 'required',
            'short_description' => 'required',
            'description' => 'required',
            'content' => 'required',
            'selecteImages' => 'required',
        ]);

        $project = Project::findOrFail($id);
        $project->titre = $data['title'];
        $project->short_description = $data['short_description'];
        $project->description = $data['description'];
        $project->content = $data['content'];
        $project->banner_id = $data['selecteImages'];


        if ($project->save()) {
            return redirect()->back()->with('success', 'Portfolio modifié avec succès');
        }

        return redirect()->back()->with('error', 'Portfolio n\'est pas modifié ! essayer à nouveau.');
    }

    public function destroy($id)
    {
        $project = Project::findOrFail($id);

        if ($project->destroy($id)) {
            return redirect()->back()->with('success', 'Portfolio a été supprimé avec succès');
        }

        return redirect()->back()->with('error', 'Portfolio n\'est pas supprimé ! essayer à nouveau.');
    }
}
