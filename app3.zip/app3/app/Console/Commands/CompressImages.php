<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Intervention\Image\Facades\Image as InterventionImage;

class CompressImages extends Command
{
    protected $signature = 'images:compress';
    protected $description = 'Compress all images in the project';

    public function handle()
    {
        $directories = [
            public_path('uploads'),
            public_path('assets/images'),
            public_path('img'),
        ];

        foreach ($directories as $directory) {
            $this->compressImagesInDirectory($directory);
        }

        $this->info('Image compression completed.');
    }

    private function compressImagesInDirectory($directory)
    {
        $batchSize = 20; // Adjust this based on the available memory and image sizes

        $images = File::files($directory);

        $batch = [];
        foreach ($images as $image) {
            $imagePath = $image->getRealPath();
            $imageExtension = $image->getExtension();

            if (in_array($imageExtension, ['jpeg', 'jpg', 'png', 'gif'])) {
                $batch[] = $imagePath;

                if (count($batch) >= $batchSize) {
                    $this->compressBatch($batch);
                    $batch = [];

                    // Pause execution for 1 second between batches to reduce memory usage
                    sleep(1);

                    // Increase memory limit and script execution time for the next batch
                    ini_set('memory_limit', '512M'); // Adjust as needed
                    set_time_limit(300); // 5 minutes; Adjust as needed
                }
            }
        }

        // Compress any remaining images in the last batch
        if (!empty($batch)) {
            $this->compressBatch($batch);
        }
    }

    private function compressBatch($batch)
    {
        foreach ($batch as $imagePath) {
            // Compress the image and save it with the same name
            $compressedImage = InterventionImage::make($imagePath)->encode('jpg', 65); // Adjust quality (0-100) as per your needs
            $compressedImage->save($imagePath);
        }
    }
}