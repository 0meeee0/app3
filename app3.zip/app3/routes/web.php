<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;


use App\Http\Controllers\HomeController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\UserProfileController;
use App\Http\Controllers\ResetPassword;
use App\Http\Controllers\ChangePassword;
use App\Http\Controllers\CollectionController;
use App\Http\Controllers\DropzoneController;
use App\Http\Controllers\GalleryController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\ContentController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ProjectCategoryController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Blog_categoryController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

route::get('/', [MainController::class, 'index'])->name('index');
route::get('/Blog/{blog}', [MainController::class, 'show_blog'])->name('show-blog');
route::get('/Portfolio/{project}', [MainController::class, 'show_portfolio'])->name('show-portfolio');
route::get('/Service/{service}', [MainController::class, 'show_service'])->name('show-service');

route::get('/about', [MainController::class, 'about_page'])->name('about_page');
route::get('/service', [MainController::class, 'service_page'])->name('service_page');
route::get('/realisation', [MainController::class, 'potfolio_page'])->name('potfolio_page');
route::get('/contact', [MainController::class, 'contact_page'])->name('contact_page');
route::get('/blogs', [MainController::class, 'blog_page'])->name('blog_page');
route::get('/devis', [MainController::class, 'devis_page'])->name('devis_page');

Route::post('/demande-de-devis', [EmailController::class, 'sendDevisEmail'])->name('sendDevisEmail');
Route::post('/contact-nous', [EmailController::class, 'sendContactEmail'])->name('sendContactEmail');

Route::get('/login', [LoginController::class, 'show'])->middleware('guest')->name('login');
Route::post('/login', [LoginController::class, 'login'])->middleware('guest')->name('login.perform');
Route::get('/reset-password', [ResetPassword::class, 'show'])->middleware('guest')->name('reset-password');
Route::post('/reset-password', [ResetPassword::class, 'send'])->middleware('guest')->name('reset.perform');
Route::get('/change-password', [ChangePassword::class, 'show'])->middleware('guest')->name('change-password');
Route::post('/change-password', [ChangePassword::class, 'update'])->middleware('guest')->name('change.perform');

Route::group(['middleware' => 'auth'], function () {
    // dashboard route
    Route::get('/dashboard', [HomeController::class, 'index'])->name('home');

    route::resource('blog-category', Blog_categoryController::class);
    route::resource('blog', BlogController::class);
    route::resource('services', ServiceController::class);
    route::resource('portfolio', ProjectController::class);
    route::resource('article', ArticleController::class);
    route::resource('category', CategoryController::class);
    route::resource('gallery', GalleryController::class);
    route::resource('collection', CollectionController::class);
    route::resource('portfolioCategory', ProjectCategoryController::class);

    route::post('/upload-image', [DropzoneController::class, 'upload_image'])->name('upload_image');
    // route::post('/upload-icon', [DropzoneController::class, 'upload_icon'])->name('upload_icon');

    // Content routes
    route::put('/index-text-update', [ContentController::class, 'index_text_update'])->name('index-text-update');
    route::put('/info_generale_update', [ContentController::class, 'info_generale_update'])->name('info_generale_update');
    route::put('/collection-content-update', [ContentController::class, 'collection_content_update'])->name('collection-content-update');
    route::put('/social-media-update', [ContentController::class, 'social_media_update'])->name('social-media-update');
    route::put('/footer-update', [ContentController::class, 'footer_update'])->name('footer-update');
    route::put('/about-us-update', [ContentController::class, 'about_us_update'])->name('about-us-update');
    route::put('/contact-update', [ContentController::class, 'contact_update'])->name('contact-update');
    route::put('/devis-update', [ContentController::class, 'devis_update'])->name('devis-update');
    route::put('/media-update', [ContentController::class, 'media_update'])->name('media-update');
    route::delete('/content/partners-page/delete/{partners}', [ContentController::class, 'partners_delete'])->name('partners-destroy');
    route::put('/content/partners-update', [ContentController::class, 'partners_update'])->name('partners-update');

    route::get('/content/home-page', [ContentController::class, 'home_page'])->name('home-page');
    route::get('/content/social-media', [ContentController::class, 'social_media_edit'])->name('social-media');
    route::get('/content/about-page', [ContentController::class, 'about_page_edit'])->name('about-page');
    route::get('/content/partners-page', [ContentController::class, 'partners_edit'])->name('partners-page');
    route::get('/content/contact', [ContentController::class, 'contact_edit'])->name('contact');

    // Settings Routes
    route::get('/settinges/pages', [SettingsController::class, 'settings_pages'])->name('settings.pages');
    route::get('/settinges/color', [SettingsController::class, 'settings_colors'])->name('settings.color');
    // route::get('/settinges/email-configuration', [SettingsController::class, 'email_pages'])->name('settings.email');

    route::put('/settings-pages-update', [SettingsController::class, 'settings_pages_update'])->name('settings-pages-update');
    route::patch('/settings-colors-update', [SettingsController::class, 'settings_colors_update'])->name('settings-colors-update');


    // Dropezone Routes
    route::post('/editor-upload-image', [DropzoneController::class, 'editor_upload_image'])->name('editor-upload-image');
    route::post('/get-all-images-api', [DropzoneController::class, 'get_images'])->name('get-all-images-api');
    route::delete('/delete-image-api', [DropzoneController::class, 'delete_image'])->name('delete-image-api');
    // route::post('/get-all-icons-api', [DropzoneController::class, 'update_icons'])->name('get-all-icons-api');
    route::get('/collection/gallery/{id}', [CollectionController::class, 'images_index'])->name('collection_images_index');
    route::post('/collection/gallery/add/{id}', [CollectionController::class, 'add_collection_images'])->name('add_collection_images');
    route::delete('/collection/gallery/delete/{id}', [CollectionController::class, 'remove_image_collection'])->name('remove-image-collection');
    route::post('/collection/gallery/get/{id}', [CollectionController::class, 'get_collection_images'])->name('get_collection_images');

    // Emails Routes
    Route::get('/emails/devis', [EmailController::class, 'devis_list'])->name('devis.list');
    Route::get('/emails/devis/{id}', [EmailController::class, 'devis_show'])->name('devis.show');
    Route::delete('/emails/devis/delete/{id}', [EmailController::class, 'devis_delete'])->name('devis.delete');
    Route::get('/emails/contact', [EmailController::class, 'contact_list'])->name('contact.list');
    Route::get('/emails/contact/{id}', [EmailController::class, 'contact_show'])->name('contact.show');
    Route::delete('/emails/contact/delete/{id}', [EmailController::class, 'contact_delete'])->name('contact.delete');

    // Profile Routes
    Route::get('/profile', [UserProfileController::class, 'show'])->name('profile');
    Route::post('/profile', [UserProfileController::class, 'update'])->name('profile.update');
    Route::get('/{page}', [PageController::class, 'index'])->name('page');
    Route::post('logout', [LoginController::class, 'logout'])->name('logout');
});
