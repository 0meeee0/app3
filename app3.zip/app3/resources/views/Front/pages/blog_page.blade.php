@extends('Front.layouts.layouts')

@section('content')
    <!-- START BLOG SECTION -->
<div class="content-box" data-simplebar="init" >
    <div class="simplebar-wrapper" style="margin: 0px;">
        <div class="simplebar-height-auto-observer-wrapper">
            <div class="simplebar-height-auto-observer"></div>
        </div>
        <div class="simplebar-mask">
            <div class="simplebar-offset" style="right: -20px; bottom: 0px;">
                <div class="simplebar-content-wrapper" style="height: 100%; padding-right: 20px; padding-bottom: 0px; overflow: hidden scroll;">
                    <div class="simplebar-content" style="padding: 0px;">
                        <div class="container">
                            <div class="lightbox-close">
                                <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                            </div>
                            <div class="portfolio-area">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="lightbox-content">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="section-tittle text-center">
                                                        <div class="tittle-detail">
                                                            <h6>Blog</h6>
                                                            <h2>Notre <span>Blog</span></h2>
                                                            <p>Explorez un monde de découvertes à travers notre blog.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="portfolio-menu text-center mb-40">
                                                <button class="active" data-filter="*">Tous</button>
                                                @foreach ($blogs_cat as $item)
                                                    <button data-filter=".{{$item->id}}">{{$item->title}}</button>
                                                @endforeach
                                            		
                                            </div>
                                            <div class="row grid filter custom">
                                                @foreach ($blogs as $item)
                                                    @php
                                                        $img = \App\Models\Image::findOrFail($item->banner_id);
                                                    @endphp
                                                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 mb-30 grid-item {{$item->category_id ?? ''}}">
                                                        <div class="blog-warp">
                                                            <div class="blog-img">
                                                                <img src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}">
                                                            </div>																	
                                                            <div class="blog-content">
                                                                <h4><a href="{{route('show-blog', ['blog' => $item->id])}}">{{$item->title}}</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>												
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="simplebar-placeholder" style="width: auto; height: 1506px;"></div>
    </div>
    <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
        <div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
    </div>
    <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
        <div class="simplebar-scrollbar" style="height: 176px; transform: translate3d(0px, 0px, 0px); display: block;"></div>
    </div>
</div>
<!-- END BLOG SECTION -->
@endsection