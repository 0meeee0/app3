@extends('Front.layouts.layouts')

<!-- START HOME SECTION -->

@section('content')
    

@php
    $home_slide_1 = \App\Models\Content::where('type', '=', 'home_slide_1')->firstOrFail();
    $home_slide_2 = \App\Models\Content::where('type', '=', 'home_slide_2')->firstOrFail();
    $home_slide_3 = \App\Models\Content::where('type', '=', 'home_slide_3')->firstOrFail();
@endphp

<section class="home-area" id="home">
    <div class="banner-wrapper vh d-flex">
        <div class="video-container">
          <!--  <video autoplay loop id="slide-1" class="video-background show-slide" muted plays-inline>
                <source src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_1['content'] }}" id="back_video" type="video/mp4">
            </video> -->
             <img id="slide-1" src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_1['content'] }}" alt="mega crafters" class="video-background">
            <img id="slide-2" src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_2['content'] }}"alt="mega crafters" class="video-background">
            <video autoplay loop id="slide-3" class="video-background" muted plays-inline>
                <source src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_3['content'] }}" id="back_video" type="video/mp4">
            </video>
        </div>
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-12 col-lg-8 text-center">
                    <div class="home-content">
                        <h1>{{ $index_text['title'] }}</h1>
                        <p>{{ $index_text['description'] }}</p>

                        @if ($settings->is_devis_section)
                            <div class="nav-bar">
                                <div class="nav-menu">
                                    <a class="nav-link btn" href="{{route('devis_page')}}">Demande de devis</a>
                                </div>
                            </div>
                        @endif

                        @include('Front.components.socialMedia')
                    </div>
                    <div class="d-flex align-items-center justify-content-center w-100 test mt-5">
                        <div class="row p-0 w-100">
                            <div class="col-4 p-1 h-100 load-block-1">
                                <div class="w-100 load-bar load-bar-1"></div>
                                <div class="row p-0 m-0 bg-container bg-1">
                                    <div class="cont">
                                        <div class="col-4 p-2 d-flex">
                                           <!-- <video autoplay loop class="rounded thub" muted plays-inline>
                                                <source src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_1['content'] }}" type="video/mp4">
                                            </video> -->
                                             
                                            <img alt="{{ $home_slide_1['title'] }}" src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_1['content'] }}" class="rounded thub">
                                         
                                        </div>
                                        <div class="col-8 p-0  slide-title">
                                            <p class="fs-6">{{ $home_slide_1['title'] }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 p-1 h-100 load-block-2">
                                <div class="w-100 load-bar load-bar-2"></div>
                                <div class="row p-0 m-0 bg-container bg-2">
                                    <div class="cont">
                                        <div class="col-4 p-2 d-flex">
                                            <img alt="{{ $home_slide_2['title'] }}" src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_2['content'] }}" class="rounded thub">
                                        </div>
                                        <div class="col-8 p-0 slide-title">
                                            <p class="fs-6">{{ $home_slide_2['title'] }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 p-1 h-100 load-block-3">
                                <div class="w-100 load-bar load-bar-3"></div>
                                <div class="row p-0 m-0 bg-container bg-3">
                                    <div class="cont">
                                        <div class="col-4 p-2 d-flex">
                                            <video autoplay loop class="rounded thub" muted plays-inline>
                                                <source src="{{ env('APP_URL') }}/public/assets/img/video/{{ $home_slide_3['content'] }}" type="video/mp4">
                                            </video>                                        </div>
                                        <div class="col-8 p-0 slide-title">
                                            <p class="fs-6">{{ $home_slide_3['title'] }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                      
                </div>
            </div>
        </div>
    </div>
</section>

@endsection

<!-- END HOME SECTION -->