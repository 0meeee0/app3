@include('Front.layouts.header')

<div class="content-box main-content py-5">
    <div class="container">
        <div class="lightbox-close">
            <a href="{{route('index')}}">
                <div class="close-btn" data-modal-close="">
                    <span class="btn-line"></span>
                </div>
            </a>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="lightbox-content">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-tittle portfolio-title text-center">
                                <div class="tittle-detail">
                                    <h6>Blog</h6>
                                    <p>{{$blog->title ?? 'Titre'}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            @php
                                $img = \App\Models\Image::findOrFail($blog->banner_id)
                            @endphp
                            <div class="about-pic align-center item">
                                <img class="about-img" src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}">
                            </div>
                        </div>  
                        <div class="col-lg-6">
                            <div class="about-text margin-30 about-margin">
                                <h2><span>{{$blog->name ?? ''}}</span></h2>
                                <p >{{$blog->description ?? ''}}</p>				
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-12 col-sm-12 col-md-8 col-lg-8 p-3">
                {!! $blog->content ?? '' !!}
            </div>
            <div class="col-12 col-sm-12 col-md-4 p-3">
                <div class="category-section p-3">
                    <h4 class="bottom-br">Blogs</h4>
                    <ul class="list-group">
                        @foreach ($blogs as $item)
                            @php
                                $img = \App\Models\Image::findOrFail($item->banner_id)
                            @endphp
                            <li class="list-group-item">
                                <a href="#">
                                    <div class="row">
                                        <div class="col-4">
                                            <img src="{{env('APP_URL')}}/public/uploads/{{$img->file_name ?? 'image-404.png'}}">
                                        </div>
                                        <div class="col-8">
                                            <p class="blog-title">
                                                {{$item->title}}
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
        @include('Front.components.partnersSlide')
    </div>
</div>