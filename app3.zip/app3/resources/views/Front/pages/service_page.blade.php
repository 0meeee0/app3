@extends('Front.layouts.layouts')

@section('content')
    <!-- START SERVICE SECTION -->
<div class="content-box" data-simplebar="init">
    <div class="simplebar-wrapper" style="margin: 0px;">
        <div class="simplebar-height-auto-observer-wrapper">
            <div class="simplebar-height-auto-observer"></div>
        </div>
        <div class="simplebar-mask">
            <div class="simplebar-offset" style="right: -20px; bottom: 0px;">
                <div class="simplebar-content-wrapper" style="height: 100%; padding-right: 20px; padding-bottom: 0px; overflow: hidden scroll;">
                    <div class="simplebar-content" style="padding: 0px;">
                        <div class="container">
                            <div class="lightbox-close">
                                <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="lightbox-content">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="section-tittle text-center">
                                                    <div class="tittle-detail">
                                                        <h6>Services</h6>
                                                        <h2>Nos <span>Services</span></h2>
                                                        <p>{{$services_page['title']}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Services section-->
                                        <div class="timeline-section single-section">
                                            <div class="row">
                                                @foreach ($services as $item)
                                                    @php
                                                        $img = \App\Models\Image::find($item->banner_id)
                                                    @endphp
                                                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 mb-30">
                                                        <div class="blog-warp">
                                                            <div class="blog-img">
                                                                <img src="{{env('APP_URL')}}/public/uploads/{{$img->file_name ?? ''}}" alt="">
                                                            </div>																	
                                                            <div class="blog-content">
                                                                <a href="{{route('show-service', $item->id)}}" class="nav-link">
                                                                    <h4>{{$item->title}}</h4>
                                                                </a>
                                                                <p>{{$item->short_description}}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="simplebar-placeholder" style="width: auto; height: 2423px;"></div>
    </div>
    <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
        <div class="simplebar-scrollbar" style="transform: translate3d(0px, 0px, 0px); display: none;"></div>
    </div>
    <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
        <div class="simplebar-scrollbar" style="height: 79px; transform: translate3d(0px, 0px, 0px); display: block;"></div>
    </div>
</div>
<!-- END SERVICE SECTION -->
@endsection