@extends('Front.layouts.layouts')
<!-- START ABOUT SECTION -->

@php
    $email_contact = \App\Http\Controllers\ContentController::get_contact_info_by_name('email_contact');  
    $adress = \App\Http\Controllers\ContentController::get_contact_info_by_name('adress');  
    $telephone = \App\Http\Controllers\ContentController::get_contact_info_by_name('telephone');
     $telephone2 = \App\Http\Controllers\ContentController::get_contact_info_by_name('telephone2'); 
@endphp

@section('content')
    

<div class="content-box" data-simplebar="init">
    <div class="simplebar-wrapper">
        <div class="simplebar-height-auto-observer-wrapper">
            <div class="simplebar-height-auto-observer"></div>
        </div>
        <div class="simplebar-mask">
            <div class="simplebar-offset">
                <div class="simplebar-content-wrapper">
                    <div class="simplebar-content">
                        <div class="container">
                            <div class="lightbox-close">
                                <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <div class="lightbox-content">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="section-tittle text-center">
                                                    <div class="tittle-detail">
                                                        <h6>Qui sommes-nous</h6>
                                                        {{-- <h2><span>About</span> me</h2> --}}
                                                        <p>{{$about_us->title ?? ''}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-7">
                                                <div class="about-pic align-center item">
                                                    <img class="about-img" src="{{env('APP_URL')}}/public/uploads/{{$about_us->file_name ?? 'about.jpeg' }}">
                                                </div>
                                                <div class="tilt-box img-tilt">
                                                    <span class="text-extra image-mask cover-background">{{$about_us->content ?? '10'}}</span>
                                                    <span class="text-extra-large ">Ans d'expérience</span>
                                                </div>
                                            </div>  
                                            <div class="col-lg-4">
                                                <div class="about-text margin-30 about-margin">
                                                    <h2><span>{{$about_us->title ?? "Sanit'R 35"}}</span></h2>
                                                    <p class="bottom-br">{{$about_us->description ?? ''}}</p>							
                                                    <ul class="about-info">
                                                        <li class="d-flex"><span>Adresse :</span> <span>{{$adress}}</span></li>
                                                        <li class="d-flex"><span>Email :</span> <span>{{$email_contact}}</span></li>
                                                    <li class="d-flex"><span>Téléphone :</span> <span>{{$telephone}} <br>{{$telephone2}} </span></li>
                                                    
                                                      
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @include('Front.components.partnersSlide')
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="simplebar-placeholder"></div>
    </div>
    <div class="simplebar-track simplebar-horizontal">
        <div class="simplebar-scrollbar"></div>
    </div>
    <div class="simplebar-track simplebar-vertical">
        <div class="simplebar-scrollbar"></div>
    </div>
</div>
<!-- END ABOUT SECTION -->

@endsection