@extends('Front.layouts.layouts')

@section('content')
    <!-- START PORTFOLIO SECTION -->
<div class="content-box" data-simplebar="init">
    <div class="simplebar-wrapper">
        <div class="simplebar-height-auto-observer-wrapper">
            <div class="simplebar-height-auto-observer"></div>
        </div>
        <div class="simplebar-mask">
            <div class="simplebar-offset">
                <div class="simplebar-content-wrapper">
                    <div class="simplebar-content">
                        <div class="container">
                            <div class="lightbox-close">
                                <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                            </div>
                            <div class="portfolio-area">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="lightbox-content">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="section-tittle text-center">
                                                        <div class="tittle-detail">
                                                            <h6>Réalisations</h6>
                                                            <h2>Notre <span>Réalisations</span></h2>
                                                            <p>{{$portfolio_page['title']}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="portfolio-menu text-center mb-40">
                                                <button class="active" data-filter="*">Tous</button>
                                                @foreach ($ProjectCategory as $item)
                                                    <button data-filter=".{{$item->id}}">{{$item->name}}</button>
                                                @endforeach
                                                {{-- <button data-filter=".cat1">Biusness</button>
                                                <button data-filter=".cat2">Consulting</button>
                                                <button data-filter=".cat3">Planing</button>
                                                <button data-filter=".cat4">Marketing</button>
                                                <button data-filter=".cat5">Other</button>		 --}}			
                                            </div>
                                            
                                            <div class="grid filter custom">
                                                <div class="row">
                                                    @foreach ($projects as $item)
                                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 grid-item {{$item->category_id}}">
                                                            <a href="{{route('show-portfolio', [ 'project' => $item->id])}}" class="nav-link">
                                                                <div class="portfolio-wrapper mb-30" style="height: 18rem">
                                                                    <div class="portfolio-img" style="height: 100%">												
                                                                        <img src="{{env('APP_URL')}}/public/uploads/{{$item['file_name']}}" alt="" style="height: 100%" />
                                                                    </div>
                                                                    <div class="portfolio-content">
                                                                        <h6>{{$item->titre}}</h6>      
                                                                    </div>
                                                                </div>
                                                            </a> 
                                                        </div>
                                                    @endforeach
                                                </div>						
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="simplebar-placeholder"></div>
    </div>
    <div class="simplebar-track simplebar-horizontal">
        <div class="simplebar-scrollbar"></div>
    </div>
    <div class="simplebar-track simplebar-vertical">
        <div class="simplebar-scrollbar"></div>
    </div>
</div>
<!-- END PORTFOLIO SECTION -->
@endsection