@include('Front.layouts.header')

<style>
    /* Custom CSS for the enlarged image */
.enlarged-img {
  max-width: 100%;
  max-height: 80vh;
  margin: 0 auto;
  display: block;
}

/* Custom CSS for the dark overlay */
.modal-backdrop.show {
  opacity: 0.85;
  background-color: black;
}
</style>
<div class="content-box main-content py-5">
    <div class="container">
        <div class="lightbox-close">
            <a href="{{route('index')}}/#portfolio">
                <div class="close-btn" data-modal-close="">
                    <span class="btn-line"></span>
                </div>
            </a>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="lightbox-content">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-tittle portfolio-title text-center">
                                <div class="tittle-detail">
                                    <h6>Réalisations</h6>
                                    <p>{{$project->titre ?? 'Titre'}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            @php
                                $img = \App\Models\Image::findOrFail($project->banner_id)
                            @endphp
                            <div class="about-pic align-center item">
                                <img class="about-img rounded" src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}">
                            </div>
                        </div>  
                     
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-12  project-content">
                {!! $project->content ?? '' !!}
            </div>
             
        </div>
        @include('Front.components.partnersSlide')
    </div>
</div>

<div class="modal modal-img">
    <span class="close">&times;</span>
    <img class="modal-content" id="modal-image">
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script>
    $(document).ready(function () {
        $('.project-content img').on('click', function () {
            const src = $(this).attr('src');
            $('#enlarged-img').attr('src', src);
            $('#imageModal').modal('show');
        });

        $('#imageModal').on('hidden.bs.modal', function () {
            $('#enlarged-img').attr('src', '');
        });
    });

    // Get references to the modal and images
    const modal = document.querySelector(".modal");
    const modalImage = document.getElementById("modal-image");
    const galleryItems = document.querySelectorAll(".project-content img");

    // Add click event listeners to each gallery item
    galleryItems.forEach((item) => {
        item.addEventListener("click", () => {
            modal.style.display = "flex";
            modalImage.src = item.src;
        });
    });

    // Close the modal when the close button is clicked
    const closeButton = document.querySelector(".close");
    closeButton.addEventListener("click", () => {
        modal.style.display = "none";
    });

    // Close the modal when clicking outside the modal content
    window.addEventListener("click", (event) => {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });
</script>