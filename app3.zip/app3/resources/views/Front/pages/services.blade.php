@include('Front.layouts.layouts')
<style>
    /* Custom CSS for the enlarged image */
.enlarged-img {
  max-width: 100%;
  max-height: 80vh;
  margin: 0 auto;
  display: block;
}

/* Custom CSS for the dark overlay */
.modal-backdrop.show {
  opacity: 0.85;
  background-color: black;
}
</style>
<div class="content-box main-content py-5">
    <div class="container">
        <div class="lightbox-close">
            <a href="{{route('index')}}">
                <div class="close-btn" data-modal-close="">
                    <span class="btn-line"></span>
                </div>
            </a>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="lightbox-content">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-tittle portfolio-title text-center">
                                <div class="tittle-detail">
                                    <h6>Service</h6>
                                    <p>{{$service->title ?? 'Titre'}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            @php
                                $img = \App\Models\Image::findOrFail($service->banner_id)
                            @endphp
                            <div class="about-pic align-center item">
                                <img class="about-img" src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}">
                            </div>
                        </div>  
                        <div class="col-lg-4">
                             <div class="category-section p-3">
                    <h4 class="bottom-br">Services</h4>
                    <ul class="list-group">
                        @foreach ($services as $item)
                            @php
                                $img = \App\Models\Image::findOrFail($item->banner_id)
                            @endphp
                            <li class="list-group-item">
                                <a href="{{route('show-service', $item->id)}}">
                                    <div class="row">
                                        <div class="col-4  ">
                                            <img src="{{env('APP_URL')}}/public/uploads/{{$img->file_name ?? 'image-404.png'}}" class="modal-fullscreen rounded mx-auto d-block">
                                        </div>
                                        <div class="col-8">
                                            <p class="blog-title">
                                                {{$item->title}}
                                            </p>
                                        </div>
                                    </div>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 p-3">
                <p class="bottom-br">{{$service->short_description ?? ''}}</p>
                <p class="text-white">{!! $service->description ?? '' !!}</p>
                 
            </div>
         
        </div>
        @if ($service->images)
            <div class="row p-0">
                <div class="wrapper">
            
                    <div class="gallery">
                        @foreach (json_decode($service->images) as $img)
                            <div class="gallery__item gallery__item--{{ $loop->index + 1 }}">
                                <span class="gallery__link">
                                    <img src="{{ asset('storage/app/public/uploads/services/' . $img) }}" class="gallery__image" />
                                    <div class="gallery__overlay"></div>
                                </span>
                            </div>
                        @endforeach
                    </div>
            
                </div>
            </div>
        @endif
        @include('Front.components.partnersSlide')
    </div>
</div>

<div class="modal modal-img">
        <span class="close">&times;</span>
        <img class="modal-content" id="modal-image">
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script>
    $(document).ready(function () {
        $('.gallery-img').on('click', function () {
            const src = $(this).attr('src');
            $('#enlarged-img').attr('src', src);
            $('#imageModal').modal('show');
        });

        $('#imageModal').on('hidden.bs.modal', function () {
            $('#enlarged-img').attr('src', '');
         });
    });

        // Get references to the modal and images
        const modal = document.querySelector(".modal");
        const modalImage = document.getElementById("modal-image");
        const galleryItems = document.querySelectorAll(".gallery__item");

        // Add click event listeners to each gallery item
        galleryItems.forEach((item) => {
            item.addEventListener("click", () => {
                modal.style.display = "flex";
                modalImage.src = item.querySelector("img").src;
            });
        });

        // Close the modal when the close button is clicked
        const closeButton = document.querySelector(".close");
        closeButton.addEventListener("click", () => {
            modal.style.display = "none";
        });

        // Close the modal when clicking outside the modal content
        window.addEventListener("click", (event) => {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });
</script>