<!-- Modal HTML -->
<div id="successModal" class="modal fade">
	<div class="modal-dialog modal-confirm">
		<div class="modal-content">
			<div class="modal-header">
				<div class="icon-box">
					<i class="fa-regular fa-circle-check" style="color: #111;"></i>
				</div>				
				<h4 class="modal-title w-100">Succès!</h4>	
			</div>
			<div class="modal-body">
				<p class="text-center">Votre {{$message ?? "message"}} a été soumis avec succès.</p>
			</div>
			<div class="modal-footer">
				<button class="btn btn-success btn-block" data-dismiss="modal">OK</button>
			</div>
		</div>
	</div>
</div>    