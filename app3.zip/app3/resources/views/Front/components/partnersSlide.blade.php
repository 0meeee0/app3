<div class="service-section section-row mb-5">
    <div class="row">
        <div class="col-md-12 text-center">
            <div class="sub-tittle">
                <h3>Nos partenaires</h3>
            </div>
        </div>														
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="outside-box-right">
                <div class="swiper-container service-slider swiper-container-initialized swiper-container-horizontal">
                    <div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(-2730px, 0px, 0px);">
                        @foreach (\App\Models\Partners::all() as $item)
                            <div class="swiper-slide services-grid item swiper-slide-duplicate-active" style="width: 175px">
                                <div class="grid">
                                    <div class="text-anim">
                                        <img src="{{env('APP_URL')}}/public/assets/img/partners/{{$item->image}}" alt="{{$item->name}}">															
                                        <div class="detail-icon"></div>
                                    </div>
                                </div>
                            </div>	
                        @endforeach
                        													
                        											
                        
                        
                    </div>
                </div>	
            </div>	
        </div>
    </div>
</div>