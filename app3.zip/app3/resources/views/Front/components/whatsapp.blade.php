<div class="amo-button-holder amo-horisontal">
    <div class="amo-button__iframe">
      <div class="amo-inner-buttons-body horisontal">
        <div class="amo-inner-buttons horisontal js-horisontal-buttons-holder">
          <div class="amo-button js-amo-control amo-button--whatsapp">
            <a href="https://wa.me/{{\App\Models\SocialMedia::where('name', '=', 'whatsapp')->value('link')}}" class="amo-button__link" target="_blank"></a>
            
          </div>
        </div>
      </div>
    </div>
  </div>