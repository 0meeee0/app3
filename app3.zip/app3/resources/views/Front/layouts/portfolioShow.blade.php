<!-- START PORTFOLIO SHOW SECTION -->
@foreach ($projects as $item)
    
    <div class="lightbox-wrapper animated portfolio_{{$item->id}}-off fadeOut" id="portfolio_{{$item->id}}" data-simplebar="init">
        <div class="simplebar-wrapper">
            <div class="simplebar-height-auto-observer-wrapper">
                <div class="simplebar-height-auto-observer"></div>
            </div>
            <div class="simplebar-mask">
                <div class="simplebar-offset">
                    <div class="simplebar-content-wrapper">
                        <div class="simplebar-content">
                            <div class="container">
                                <div class="lightbox-close">
                                    <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="lightbox-content">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="section-tittle portfolio-title text-center">
                                                        <div class="tittle-detail">
                                                            <h6>Portfolio</h6>
                                                            <p>{{$item->titre ?? ''}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-pic align-center item">
                                                        <img class="about-img" src="{{env('APP_URL')}}/public/uploads/{{$item->file_name}}" alt="">
                                                    </div>
                                                </div>  
                                                <div class="col-lg-6">
                                                    <div class="about-text margin-30 about-margin">
                                                        <h2><span>{{$item->name ?? ''}}</span></h2>
                                                        <p class="bottom-br">{{$item->short_description ?? ''}}</p>		
                                                        <p class="pt-3">{{$item->description ?? ''}}</p>					
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5 p-3">
                                    {!! $item->content ?? '' !!}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="simplebar-placeholder"></div>
        </div>
        <div class="simplebar-track simplebar-horizontal">
            <div class="simplebar-scrollbar"></div>
        </div>
        <div class="simplebar-track simplebar-vertical">
            <div class="simplebar-scrollbar"></div>
        </div>
    </div>



@endforeach

<!-- END PORTFOLIO SHOW SECTION -->