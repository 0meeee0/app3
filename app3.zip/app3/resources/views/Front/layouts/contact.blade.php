<!-- START CONTACT SECTION -->

@php
    $email_contact = \App\Http\Controllers\ContentController::get_contact_info_by_name('email_contact');  
    $adress = \App\Http\Controllers\ContentController::get_contact_info_by_name('adress');  
    $telephone = \App\Http\Controllers\ContentController::get_contact_info_by_name('telephone');  
@endphp

<div class="lightbox-wrapper animated contact-off fadeOut" id="contact" data-simplebar="init">
    <div class="simplebar-wrapper">
        <div class="simplebar-height-auto-observer-wrapper">
            <div class="simplebar-height-auto-observer"></div>
        </div>
        <div class="simplebar-mask">
            <div class="simplebar-offset">
                <div class="simplebar-content-wrapper">
                    <div class="simplebar-content">
                        <div class="container">
                            <div class="lightbox-close">
                                <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                            </div>
                            <div class="portfolio-area">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="lightbox-content">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="section-tittle text-center">
                                                        <div class="tittle-detail">
                                                            <h6>contact</h6>
                                                            <h2><span>contactez-</span>Nous</h2>
                                                            <p>{{$contact_page['title']}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row justify-content-center">
                                                <div class="col-md-4 mb-30">
                                                    <div class="author-box">
                                                        <div class="author-detail">
                                                            <div class="row justify-content-center">
                                                                <div class="col-md-12 mb-30">
                                                                    <div class="author-icon">
                                                                        <i class="fa-solid fa-user"></i>
                                                                    </div>
                                                                    <div class="author-single">												
                                                                        <h4>Notre Email</h4>
                                                                        <span>{{$email_contact}}</span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12 mb-30">
                                                                    <div class="author-icon">
                                                                        <i class="fa-solid fa-globe"></i>
                                                                    </div>
                                                                    <div class="author-single">
                                                                        <h4>Notre Emplacement</h4>
                                                                        <span>{{$adress}}</span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12">
                                                                    <div class="author-icon">
                                                                        <i class="fa-solid fa-phone"></i>
                                                                    </div>
                                                                    <div class="author-single">
                                                                        <h4>Appelez-nous</h4>
                                                                        <span>{{$telephone}}</span>
                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="load" id="load"></div>
                                                    <form class="contact-form" id="contact-form" method="post" action="{{route('sendContactEmail')}}">																																	
                                                        <!-- form element -->
                                                        @csrf
                                                        <div class="row">
                                                            <div class="col-md-6 form-group">
                                                                <input name="name" type="text" class="form-control" placeholder="Nom complet" required>
                                                                <div class="icon-bg"><i class="fa-solid fa-user"></i></div>
                                                            </div>
                                                            <div class="col-md-6 form-group">
                                                                <input name="email" type="email" class="form-control" placeholder="Email" required>
                                                                <div class="icon-bg"><i class="fa-solid fa-envelope"></i></div>
                                                            </div>
                                                            <div class="col-md-6 form-group">
                                                                <input name="phone" type="text" class="form-control" placeholder="Téléphone" required>
                                                                <div class="icon-bg"><i class="fa-solid fa-phone"></i></div>
                                                            </div>
                                                            <div class="col-md-6 form-group">
                                                                <input name="subject" type="text" class="form-control" placeholder="Sujet" required>
                                                                <div class="icon-bg"><i class="fa-brands fa-hire-a-helper"></i></div>
                                                            </div>
                                                            <div class="col-12 form-group">
                                                                <textarea name="message" class="form-control" rows="2" placeholder="Message" required></textarea>
                                                                <div class="icon-bg"><i class="fa-solid fa-pen-to-square"></i></div>
                                                            </div>
                                                            {{-- <div class="col-12">
                                                                <div class="alert alert-success contact-msg" style="display: none" role="alert">
                                                                    Your message was sent successfully.
                                                                </div>
                                                            </div> --}}
                                                            <div class="col-12 text-right">
                                                                <button class="g-recaptcha btn btn-success" 
                                                                data-sitekey="{{ config('services.recaptcha.site_key') }}" 
                                                                data-callback='onSubmit' 
                                                                data-action='contact' type="submit" value="envoyer">Envoyer</button>
                                                            </div>
                                                        </div>
                                                        <!-- end form element -->
                                                    </form>
                                                </div>														
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="simplebar-placeholder"></div>
    </div>
    <div class="simplebar-track simplebar-horizontal">
        <div class="simplebar-scrollbar"></div>
    </div>
    <div class="simplebar-track simplebar-vertical">
        <div class="simplebar-scrollbar"></div>
    </div>
</div>
<script>

function onSubmit(token) {
    var initialCsrfToken = $('meta[name="csrf-token"]').attr('content');

    // Serialize the form data
    var formData = $('#contact-form').serialize();

    // form
    $('#contact-form').css("display", "none");
    // loading div
    $('#load').css("display", "block");

    $.ajax({
        type: 'POST',
        url: "{{ route('sendContactEmail') }}",
        data: formData,
        headers: {
            'X-CSRF-TOKEN': initialCsrfToken
        },
        success: function(response) {
            // loading div
            $('#load').css("display", "none");
            // form
            $('#contact-form').css("display", "block");
    
            // Refresh the CSRF token
            $('#contact-form input[name="_token"]').val(initialCsrfToken);

            // show success modal
            $('#successModal').modal('show');
            
            // Clear all input fields and textareas
            $('#contact-form input, #contact-form textarea').val('');
        },
        error: function(xhr, status, error) {
            // Handle the error response
            console.error('Error sending email:', error);
            
            $('#load').css("display", "none");
            // form
            $('#contact-form').css("display", "block");
    
            // Refresh the CSRF token
            $('#contact-form input[name="_token"]').val(initialCsrfToken);
        }
    });
}

</script>
<!-- END CONTACT SECTION -->