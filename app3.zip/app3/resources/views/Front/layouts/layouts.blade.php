<!doctype html>
<html class="no-js" lang="fr">
<!--
   https://www.vitrine360.hostoplus.com/ - Site Information

   Créé par Mega Crafters sarl - Décembre 2023

   Contact: 0668646054

   Description:
   Ce site a été développé par Mega Crafters sarl pour présenter les concepts de cuisine innovants. La conception et la mise en œuvre ont été achevées en décembre 2023. Pour toute question ou information supplémentaire, veuillez contacter le numéro de téléphone indiqué.

   Version History:
   - Version 1.0 (Décembre 2023): Lancement initial du site.

   Technical Details:
   - Langages utilisés : HTML5, CSS3, JavaScript
   - Framework : laravel
   - Responsiveness : Le site est conçu pour être compatible avec les appareils mobiles.

   Avis de droits d'auteur:
   Tous droits réservés © 2023 vitrine360.hostoplus.com. Aucune reproduction autorisée sans permission.

   Besoin d'assistance technique ou avez-vous des commentaires?
   Veuillez contacter notre équipe de support à contact@hostoplus.com

   Merci de visiter https://www.vitrine360.hostoplus.com/!
-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{$settings->site_title ?? 'Kitchen concept'}}</title>
    <meta name="description" content="{{$settings->meta_description}}">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="icon" type="image/png" href="{{env('APP_URL')}}/public/assets/img/favicon/{{$settings->favicon}}"
        sizes="32x32" />
    {{--
    <link rel="icon" href="{{env('APP_URL')}}/public/assets/img/cropped-icn-192x192.png" sizes="192x192" /> --}}
    <!-- Place favicon.ico in the root directory -->

    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"
        integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    {{-- RECAPTCHA API --}}
    <script src="https://www.google.com/recaptcha/api.js">
        console.log("App Favicon {{env('APP_URL')}}/public/assets/img/favicon/{{$settings->favicon}}")
    </script>
    <!--
   vitrine360.hostoplus.com - Site Information

   Créé par Mega Crafters sarl - Décembre 2023

   Contact: 0668646054

   Description:
   Ce site a été développé par Mega Crafters sarl pour présenter les concepts de cuisine innovants. La conception et la mise en œuvre ont été achevées en décembre 2023. Pour toute question ou information supplémentaire, veuillez contacter le numéro de téléphone indiqué.

   Version History:
   - Version 1.0 (Décembre 2023): Lancement initial du site.

   Technical Details:
   - Langages utilisés : HTML5, CSS3, JavaScript
   - Framework : laravel
   - Responsiveness : Le site est conçu pour être compatible avec les appareils mobiles.

   Avis de droits d'auteur:
   Tous droits réservés © 2023 vitrine360.hostoplus.com. Aucune reproduction autorisée sans permission.

   Besoin d'assistance technique ou avez-vous des commentaires?
   Veuillez contacter notre équipe de support à contact@hostoplus.com

   Merci de visiter vitrine360.hostoplus.com!
-->
    <!-- START ALL CSS -->
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/animate.min.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/bootstrap.min.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/swiper.min.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/lity.min.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/simplebar.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/line-awesome.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/corine-style.css">
    <link rel="stylesheet" href="{{env('APP_URL')}}/public/assets/css/Front/corine-responsive.css">

    <style>
        :root {
            --back-color: {{\App\Models\Setting::find(1)->back_color}} ;

            --primary-color: {{\App\Models\Setting::find(1)->primary_color}} ;
        }
    </style>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,500i,600,700,800&display=swap"
        rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <!-- END ALL CSS -->
</head>

<body>


    <!-- START PRELOADER -->
    <div class="holaa">
        <div class="Shape_5a Top_Border"></div>
    </div>
    <!-- END PRELOADER -->

    <!-- START TRANSITION EFFECT -->
    {{-- <div id="overlay-effect"></div> --}}
    <!-- END TRANSITION EFFECT -->
    <!--
   vitrine360.hostoplus.com - Site Information

   Créé par Mega Crafters sarl - Décembre 2023

   Contact: 0668646054

   Description:
   Ce site a été développé par Mega Crafters sarl pour présenter les concepts de cuisine innovants. La conception et la mise en œuvre ont été achevées en décembre 2023. Pour toute question ou information supplémentaire, veuillez contacter le numéro de téléphone indiqué.

   Version History:
   - Version 1.0 (Décembre 2023): Lancement initial du site.

   Technical Details:
   - Langages utilisés : HTML5, CSS3, JavaScript
   - Framework : laravel
   - Responsiveness : Le site est conçu pour être compatible avec les appareils mobiles.

   Avis de droits d'auteur:
   Tous droits réservés © 2023 vitrine360.hostoplus.com. Aucune reproduction autorisée sans permission.

   Besoin d'assistance technique ou avez-vous des commentaires?
   Veuillez contacter notre équipe de support à contact@hostoplus.com

   Merci de visiter vitrine360.hostoplus.com!
-->

    <!--
   vitrine360.hostoplus.com - Site Information

   Créé par Mega Crafters sarl - Décembre 2023

   Contact: 0668646054

   Description:
   Ce site a été développé par Mega Crafters sarl pour présenter les concepts de cuisine innovants. La conception et la mise en œuvre ont été achevées en décembre 2023. Pour toute question ou information supplémentaire, veuillez contacter le numéro de téléphone indiqué.

   Version History:
   - Version 1.0 (Décembre 2023): Lancement initial du site.

   Technical Details:
   - Langages utilisés : HTML5, CSS3, JavaScript
   - Framework : laravel
   - Responsiveness : Le site est conçu pour être compatible avec les appareils mobiles.

   Avis de droits d'auteur:
   Tous droits réservés © 2023 vitrine360.hostoplus.com. Aucune reproduction autorisée sans permission.

   Besoin d'assistance technique ou avez-vous des commentaires?
   Veuillez contacter notre équipe de support à contact@hostoplus.com

   Merci de visiter vitrine360.hostoplus.com!
-->
    @include('Front.layouts.header')
    @yield('content')
    @include('Front.components.whatsapp')


    <!-- START ALL JS/SCRIPT -->
    <script src="{{env('APP_URL')}}/public/assets/js/Front/vendor/modernizr-3.6.0.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/vendor/jquery-3.5.1.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/bootstrap.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/isotope.pkgd.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/imagesloaded.pkgd.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/jquery.barfiller.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/circle-progress.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/animatedModal.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/jquery.counterup.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/lity.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/tilt.jquery.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/simplebar.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/waypoints.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/typewritter.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/swiper.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/jquery.scrollUp.min.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/corine-main.js"></script>
    <script src="{{env('APP_URL')}}/public/assets/js/Front/plugins.js"></script>
    <!-- END ALL JS/SCRIPT -->

    <!--

   vitrine360.hostoplus.com - Site Information

   Créé par Mega Crafters sarl - Décembre 2023

   Contact: 0668646054

   Description:
   Ce site a été développé par Mega Crafters sarl pour présenter les concepts de cuisine innovants. La conception et la mise en œuvre ont été achevées en décembre 2023. Pour toute question ou information supplémentaire, veuillez contacter le numéro de téléphone indiqué.

   Version History:
   - Version 1.0 (Décembre 2023): Lancement initial du site.

   Technical Details:
   - Langages utilisés : HTML5, CSS3, JavaScript
   - Framework : laravel
   - Responsiveness : Le site est conçu pour être compatible avec les appareils mobiles.

   Avis de droits d'auteur:
   Tous droits réservés © 2023 vitrine360.hostoplus.com. Aucune reproduction autorisée sans permission.

   Besoin d'assistance technique ou avez-vous des commentaires?
   Veuillez contacter notre équipe de support à contact@hostoplus.com

   Merci de visiter vitrine360.hostoplus.com!
-->
</body>

</html>