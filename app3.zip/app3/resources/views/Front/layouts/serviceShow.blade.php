<!-- START SERVICE SECTION -->
@foreach ($services as $item)
        
    <div class="lightbox-wrapper animated service{{$item->id}}-off fadeOut" id="service{{$item->id}}" data-simplebar="init">
        <div class="simplebar-wrapper" style="margin: 0px;">
            <div class="simplebar-height-auto-observer-wrapper">
                <div class="simplebar-height-auto-observer"></div>
            </div>
            <div class="simplebar-mask">
                <div class="simplebar-offset" style="right: -20px; bottom: 0px;">
                    <div class="simplebar-content-wrapper" style="height: 100%; padding-right: 20px; padding-bottom: 0px; overflow: hidden scroll;">
                        <div class="simplebar-content" style="padding: 0px;">
                            <div class="container">
                                <div class="lightbox-close">
                                    <div class="close-btn" data-modal-close=""><span class="btn-line"></span></div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="lightbox-content">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="section-tittle text-center">
                                                        <div class="tittle-detail">
                                                            <h6>Services</h6>
                                                            <h2>Nos <span>Services</span></h2>
                                                            <p>{{$services_page['title']}}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Services section-->
                                            @php
                                                $img = \App\Models\Image::findOrFail($item->banner_id)
                                            @endphp
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-pic align-center item">
                                                        <img class="about-img" src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}" alt="">
                                                    </div>
                                                </div>  
                                                <div class="col-lg-6">
                                                    <div class="about-text margin-30 about-margin">
                                                        <h2><span>{{$item->name ?? ''}}</span></h2>
                                                        <p class="bottom-br">{{$item->short_description ?? ''}}</p>		
                                                        <p class="pt-3">{{$item->description ?? ''}}</p>					
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="simplebar-placeholder" style="width: auto; height: 2423px;"></div>
        </div>
    </div>

@endforeach
<!-- END SERVICE SECTION -->