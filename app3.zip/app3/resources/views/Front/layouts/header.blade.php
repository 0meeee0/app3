<!-- START HEADER SECTION -->
<div class="header-area small-menu">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-9">
                <div class="logo">
                    <a href="{{route('index')}}">
                        <img src="{{env('APP_URL')}}/public/uploads/{{$index_text['file_name']}}"
                            alt="{{$settings->site_title ?? 'Virine 360'}}" />
                    </a>
                </div>
            </div>
            <script>
                console.log("App Logo {{env('APP_URL')}}/public/uploads/{{$index_text['file_name']}}")
            </script>
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-3 text-right">
                <div class="main-menu nav-bar text-right">
                    <ul class="nav-menu">
                        @if ($settings->is_about_section)
                        <li><a class="nav-link {{ request()->route()->named('about_page') ? 'active' : '' }}"
                                href="{{route('about_page')}}">Qui sommes-nous</a></li>
                        @endif
                        @if ($settings->is_service_section)
                        <li><a class="nav-link {{ request()->route()->named('service_page') ? 'active' : '' }}"
                                href="{{route('service_page')}}">Services</a></li>
                        @endif
                        @if ($settings->is_portfolio_section)
                        <li><a class="nav-link {{ request()->route()->named('potfolio_page') ? 'active' : '' }}"
                                href="{{route('potfolio_page')}}">Réalisations</a></li>
                        @endif
                        @if ($settings->is_blog_section)
                        <li><a class="nav-link {{ request()->route()->named('blog_page') ? 'active' : '' }}"
                                href="{{route('blog_page')}}">Blog</a></li>
                        @endif
                        @if ($settings->is_contact_section)
                        <li><a class="nav-link {{ request()->route()->named('contact_page') ? 'active' : '' }}"
                                href="{{route('contact_page')}}">Contactez-nous</a></li>
                        @endif

                    </ul>
                </div>
                <nav role="navigation" class="d-block d-lg-none">
                    <div id="menuToggle">
                        <input type="checkbox">
                        <span></span>
                        <span></span>
                        <span></span>
                        <div class="mobile-menu nav-bar" id="mobile-menu">
                            <ul class="nav-menu">
                                @if ($settings->is_about_section)
                                <li><a class="nav-link {{ request()->route()->named('about_page') ? 'active' : '' }}"
                                        href="{{route('about_page')}}">Qui sommes-nous</a></li>
                                @endif
                                @if ($settings->is_service_section)
                                <li><a class="nav-link {{ request()->route()->named('service_page') ? 'active' : '' }}"
                                        href="{{route('service_page')}}">Services</a></li>
                                @endif
                                @if ($settings->is_portfolio_section)
                                <li><a class="nav-link {{ request()->route()->named('potfolio_page') ? 'active' : '' }}"
                                        href="{{route('potfolio_page')}}">Réalisations</a></li>
                                @endif
                                @if ($settings->is_blog_section)
                                <li><a class="nav-link {{ request()->route()->named('blog_page') ? 'active' : '' }}"
                                        href="{{route('blog_page')}}">Blog</a></li>
                                @endif
                                @if ($settings->is_contact_section)
                                <li><a class="nav-link {{ request()->route()->named('contact_page') ? 'active' : '' }}"
                                        href="{{route('contact_page')}}">Contactez-nous</a></li>
                                @endif

                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- END HEADER SECTION -->