<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 "
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="{{ route('home') }}">
            <img  src="{{env('APP_URL')}}/public/uploads/{{$index_text['file_name']}}" class="navbar-brand-img " alt="{{ $settings->site_title }}">


        </a>
    </div>
    <hr class="horizontal dark mt-0">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'home' ? 'active' : '' }}" href="{{ route('home') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-tv-2 text-primary text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Accueil</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link {{ Route::currentRouteName() == 'profile' ? 'active' : '' }}" href="{{ route('profile') }}">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Profile</span>
                </a>
            </li>



            {{-- <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'collection.index' ? 'active' : '' }}" href="{{ route('collection.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-collection text-sm opacity-10" style="color: blue"></i>
                        </div>
                        <span class="nav-link-text ms-1">Collections</span>
                    </a>
                </li>
            </li> --}}

            {{-- <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'article.index' ? 'active' : '' }}" href="{{ route('article.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-bag-17 text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Article</span>
                    </a>
                </li>
            </li> --}}

            <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'portfolioCategory.index' ? 'active' : '' }}" href="{{ route('portfolioCategory.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-ungroup text-sm opacity-10" style="color: rgb(134, 78, 0)"></i>
                        </div>
                        <span class="nav-link-text ms-1">Réalisations Catégories</span>
                    </a>
                </li>
            </li>
            <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'portfolio.index' ? 'active' : '' }}" href="{{ route('portfolio.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-archive-2 text-primary text-sm opacity-10"></i>
                        </div>
                        <span class="nav-link-text ms-1">Réalisations</span>
                    </a>
                </li>
            </li>

            <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'services.index' ? 'active' : '' }}" href="{{ route('services.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-briefcase-24 text-sm opacity-10" style="color: gray"></i>
                        </div>
                        <span class="nav-link-text ms-1">Services</span>
                    </a>
                </li>
            </li>

            <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'blog-category.index' ? 'active' : '' }}" href="{{ route('blog-category.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-single-copy-04 text-sm opacity-10" style="color: rgb(179, 1, 1)"></i>
                        </div>
                        <span class="nav-link-text ms-1">Blog Catégories</span>
                    </a>
                </li>
            </li>

            <li class="nav-item">
                <li class="nav-item">
                    <a class="nav-link {{ Route::currentRouteName() == 'blog.index' ? 'active' : '' }}" href="{{ route('blog.index') }}">
                        <div class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                            <i class="ni ni-single-copy-04 text-sm opacity-10" style="color: rgb(1, 16, 179)"></i>
                        </div>
                        <span class="nav-link-text ms-1">Blog</span>
                    </a>
                </li>
            </li>

            <li class="nav-item">
                <a data-bs-toggle="collapse" href="#emails" class="nav-link collapsed" aria-controls="emails" role="button" aria-expanded="false">
                    <div class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-email-83 text-sm opacity-10" style="color: rgb(0, 0, 0)"></i>
                    </div>
                    <span class="nav-link-text ms-1">Devis & Contacts</span>
                </a>
                <div class="collapse" id="emails" style="">
                    <ul class="nav ms-4">
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('devis.list')}}">
                            <span class="sidenav-mini-icon"> D </span>
                            <span class="sidenav-normal"> Devis </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('contact.list')}}">
                            <span class="sidenav-mini-icon"> C </span>
                            <span class="sidenav-normal"> Contact </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item">
                <a data-bs-toggle="collapse" href="#settings" class="nav-link collapsed" aria-controls="ecommerceExamples" role="button" aria-expanded="false">
                    <div class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-settings-gear-65 text-sm opacity-10" style="color: rgb(0, 0, 0)"></i>
                    </div>
                    <span class="nav-link-text ms-1">Paramètres</span>
                </a>
                <div class="collapse" id="settings" style="">
                    <ul class="nav ms-4">
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('settings.pages')}}">
                            <span class="sidenav-mini-icon"> T </span>
                            <span class="sidenav-normal"> Toutes les pages </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('settings.color')}}">
                            <span class="sidenav-mini-icon"> C </span>
                            <span class="sidenav-normal"> Couleur </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="nav-item">
                <a data-bs-toggle="collapse" href="#ecommerceExamples" class="nav-link collapsed" aria-controls="ecommerceExamples" role="button" aria-expanded="false">
                    <div class="icon icon-shape icon-sm text-center d-flex align-items-center justify-content-center">
                        <i class="ni ni-book-bookmark text-success text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Contenu</span>
                </a>
                <div class="collapse" id="ecommerceExamples" style="">
                    <ul class="nav ms-4">
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('home-page')}}">
                            <span class="sidenav-mini-icon"> P </span>
                            <span class="sidenav-normal"> Page d'accueil </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('contact')}}">
                            <span class="sidenav-mini-icon"> C </span>
                            <span class="sidenav-normal"> Contact </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('social-media')}}">
                            <span class="sidenav-mini-icon"> R </span>
                            <span class="sidenav-normal"> Reseau sociaux </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('about-page')}}">
                            <span class="sidenav-mini-icon"> A </span>
                            <span class="sidenav-normal"> A propos </span>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link " href="{{route('partners-page')}}">
                            <span class="sidenav-mini-icon"> P </span>
                            <span class="sidenav-normal"> Partenaires </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>


        </ul>
    </div>

</aside>
