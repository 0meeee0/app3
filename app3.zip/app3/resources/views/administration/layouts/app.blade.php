<!DOCTYPE html>
<html lang="fr">
<!--
vitrine 360, un web-miam concocté par MEGA Crafters. Design gourmand, projets croustillants.
Croquez l'inspiration, c'est prêt dès décembre 2023 ! (0668646054)
-->

<head>
  <meta charset="utf-8" />
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="{{env('APP_URL')}}/public/img/apple-icon.png">

  <link rel="icon" href="{{env('APP_URL')}}/public/assets/img/favicon/{{$settings->favicon}}" sizes="32x32" />
  <title>
    {{$settings->site_title ?? 'Vitrine 360'}}
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="{{env('APP_URL')}}/public/assets/css/administration/nucleo-icons.css" rel="stylesheet" />
  <link href="{{env('APP_URL')}}/public/assets/css/administration/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="{{env('APP_URL')}}/public/assets/css/administration/nucleo-svg.css" rel="stylesheet" />

  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

  <!-- CSS Files -->
  <link id="pagestyle" href="{{env('APP_URL')}}/public/assets/css/administration/argon-dashboard.css"
    rel="stylesheet" />

  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">
  <!--
vitrine 360, un web-miam concocté par MEGA Crafters. Design gourmand, projets croustillants.
Croquez l'inspiration, c'est prêt dès décembre 2023 ! (0668646054)
-->

  <link href="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone.css" rel="stylesheet" type="text/css" />
  <script src="https://unpkg.com/dropzone@6.0.0-beta.1/dist/dropzone-min.js"></script>
  <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

  {!! $style ?? '' !!}
  <style>
    :root {
      --back-color: {{\App\Models\Setting::find(1)->back_color}};
      --primary-color: {{\App\Models\Setting::find(1)->primary_color}};
    }
  </style>
</head>

<body class="{{ $class ?? '' }}">
  <!--
vitrine 360, un web-miam concocté par MEGA Crafters. Design gourmand, projets croustillants.
Croquez l'inspiration, c'est prêt dès décembre 2023 ! (0668646054)
-->
  @guest
  @yield('content')
  @endguest

  @auth
  @if (in_array(request()->route()->getName(), ['sign-in-static', 'sign-up-static', 'login', 'register',
  'recover-password', 'rtl', 'virtual-reality']))
  @yield('content')
  @else
  @if (!in_array(request()->route()->getName(), ['profile', 'profile-static']))
  <div class="min-height-300 bg-primary position-absolute w-100"></div>
  @elseif (in_array(request()->route()->getName(), ['profile-static', 'profile']))
  <div class="position-absolute w-100 min-height-300 top-0 dashboard-back-img" style="">
    <span class="mask bg-primary opacity-6"></span>
  </div>
  @endif
  @include('administration.layouts.navbars.auth.sidenav')
  <main class="main-content border-radius-lg">
    @yield('content')
  </main>
  {{-- @include('administration.components.fixed-plugin') --}}
  @endif
  @endauth

  <!--
vitrine 360, un web-miam concocté par MEGA Crafters. Design gourmand, projets croustillants.
Croquez l'inspiration, c'est prêt dès décembre 2023 ! (0668646054)
-->
  <!--   Core JS Files   -->
  <script src="{{env('APP_URL')}}/public/assets/js/core/popper.min.js"></script>
  <script src="{{env('APP_URL')}}/public/assets/js/core/bootstrap.min.js"></script>
  <script src="{{env('APP_URL')}}/public/assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="{{env('APP_URL')}}/public/assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
  </script>
  <!--
vitrine 360, un web-miam concocté par MEGA Crafters. Design gourmand, projets croustillants.
Croquez l'inspiration, c'est prêt dès décembre 2023 ! (0668646054)
-->
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="{{env('APP_URL')}}/public/assets/js/argon-dashboard.js"></script>
  @stack('js');
</body>

</html>