<!-- Image Modal -->
<div class="modal fade" id="dropzoneImagesCheck" tabindex="-1" aria-labelledby="imagesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-light">

                <nav>
                    <div class="nav nav-tabs" id="nav-image-tab" role="tablist">
                        <button class="nav-link active my-btn-refresh" id="nav-home-image-tab" data-bs-toggle="tab"
                            data-bs-target="#nav-home-image" type="button" role="tab" aria-controls="nav-home-image"
                            aria-selected="true">Choisir</button>
                        <button class="nav-link" id="nav-profile-image-tab" data-bs-toggle="tab"
                            data-bs-target="#nav-profile-image" type="button" role="tab"
                            aria-controls="nav-profile-image" aria-selected="false">Télécharger nouveau</button>
                    </div>
                </nav>

                {{-- Success Alert --}}
                <div id="imgDeletingAlert" style="
                    background: rgb(0, 255, 0, 0.2);
                    padding: 10px;
                    color: green;
                    border-radius: 5px;
                    display: none;
                ">Image bien supprimée!</div>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="tab-content" id="nav-image-tabContent">
                    <div class="tab-pane fade show active" id="nav-home-image" role="tabpanel"
                        aria-labelledby="nav-home-image-tab" tabindex="0">
                        <div class="image-select p-3">
                            <div class="image-select-header d-flex">
                                <div class="image-select-header-filter w-25">

                                </div>
                                <div class="image-select-header-search ">
                                    <div class="modal-search">
                                        <input class="search-image-input" placeholder="Search..." type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="image-select-body row" id="images-listing"></div>
                            <nav aria-label="Page navigation">
                                <ul class="pagination" id="pagination-images">
                                    <!-- Pagination links will be generated dynamically here -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile-image" role="tabpanel"
                        aria-labelledby="nav-profile-image-tab" tabindex="0">
                        <div class="p-3 image-drop">
                            <form action="{{ route('upload_image') }}" method="post" enctype="multipart/form-data"
                                id="dropzoneImage" class="dropzone">
                                @csrf

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                <button id='select-selected-images' type="button" class="btn btn-primary"
                    onclick="save_images_changes_modal()">Sauvegarder</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        get_all_images();
        // get_all_icons();
    });

    function deleteImgFunc(id) {
        $.ajax({
            url: "{{route('delete-image-api')}}",
            method: 'DELETE',
            data: {
                "_token": "{{ csrf_token() }}",
                "id": id,
            },
            success: function (response) {
                console.log(response);
                $('#imgDeletingAlert').show();
                get_all_images();
                setTimeout(() => {
                    $('#imgDeletingAlert').hide();
                }, 3000);
            },
            error: function (xhr) {
                console.log("error");
                console.log(xhr);
            }
        });
    }

    var dropzoneImage = new Dropzone('#dropzoneImage', {
        thumbnailWidth: 400,
        maxFilesize: 25,
        acceptedFiles: ".jpeg,.jpg,.png,.gif,.webp,.JPG",
    });

    // Add a success event listener
    dropzoneImage.on('success', function(file, response) {
        console.log("something 1");
        get_all_images();
    });

    function save_images_changes_modal() {

        const checkboxes = document.querySelectorAll('input[name="images"]:checked');

        // Initialize an array to store the IDs and values as objects
        const selectedItems = [];

        // Loop through the checked checkboxes and extract the information
        checkboxes.forEach((checkbox) => {
            const id = checkbox.id;
            const name = checkbox.value;
            selectedItems.push({ id, name });
        });


        var selected_images_inputs = "";
        var images_thumb = "";

        var img_num = 0;

        selectedItems.forEach(element => {
            selected_images_inputs += "<input type='hidden' name='selecteImages' value='" + element.id + "' >";
            images_thumb += "<div class='p-2' id='" + element.id + "'><img src='{{env('APP_URL')}}/public/uploads/" + element.name + "' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'></div>";
            img_num++;
        });

        $('#selected_images_input_value').val("  " + img_num + " Fichiers sélectionnés");

        $('#selected_images').html(selected_images_inputs);
        $('#images-thumb').html(images_thumb);

        $('#dropzoneImagesCheck').modal('hide');
        $('body').removeClass('model-open');
        $('.modal-backdrop').remove();

    }

    function get_all_images(page = 1) {
        $.ajax({
            url: "{{route('get-all-images-api')}}",
            method: 'POST',
            data: {
                "_token": "{{ csrf_token() }}",
                "page": page,
            },
            success: function (response) {
                var html = "";
                var temp = "";
                response.data.forEach(img => {
                    img.id !== 1 ? temp +=  `
                    <div style="position: relative;" class="col-md-4 col-lg-3 col-sm-6 col-xs-12" style="margin-top: 2rem">
                        <label style="width: 100%">
                            <div class="card" style="height: 15rem m-1">
                                <img src="{{ env('APP_URL') }}/public/uploads/${ img.file_name }"
                                    alt="" class="img-thumbnail"
                                    style="width: 100%; height: 10rem">
                                    <div class="card-body">
                                    <h5 class="card-title">${ img.file_name }</h5>
                                </div>
                            </div>
                            <input type="radio" style="position: absolute;top:5%; left:10%; width: 2rem; height: 2rem;" id="${ img.id }" name="images" value="${ img.file_name }">
                            <button id="deleteImg${ img.id }" onclick="deleteImgFunc(${ img.id })" class="deleteImgBtn">X</button>
                        </label>
                    </div>` : temp += '';
                });

                html += temp
                $('#images-listing').html(html)

                // Create pagination links dynamically
                var pagination_images = '';
                for (var i = 1; i <= response.last_page; i++) {
                    pagination_images += `<li class="page-item${i === response.current_page ? 'active' : ''}">
                                    <a class="page-link" href="javascript:void(0);" onclick="get_all_images(${i})">${i}</a>
                                    </li>`;
                }

                $('#pagination-images').html(pagination_images);
            },
            error: function (xhr) {
                console.log("error");
                console.log(xhr);
            }
        });
    }

    // function save_icon_changes_modal() {

    //     const checkboxes = document.querySelectorAll('input[name="icons"]:checked');

    //     // Initialize an array to store the IDs and values as objects
    //     const selectedItems = [];

    //     // Loop through the checked checkboxes and extract the information
    //     checkboxes.forEach((checkbox) => {
    //         const id = checkbox.id;
    //         const name = checkbox.value;
    //         selectedItems.push({ id, name });
    //     });


    //     var selected_icons_inputs = "";
    //     var icons_thumb = "";

    //     var icon_num = 0;

    //     selectedItems.forEach(element => {
    //         selected_icons_inputs += "<input type='hidden' name='selecteIcons' value='" + element.id + "' >";
    //         icons_thumb += "<div class='p-2' id='" + element.id + "'><img src='{{env('APP_URL')}}/public/uploads/" + element.name + "' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'></div>";
    //         icon_num++;
    //     });

    //     $('#selected_icons_input_value').val("  " + icon_num + " Fichiers sélectionnés");

    //     $('#selected_icons').html(selected_icons_inputs);
    //     $('#icons-thumb').html(icons_thumb);

    //     $('#dropzoneIconsCheck').modal('hide');
    //     $('body').removeClass('model-open');
    //     $('.modal-backdrop').remove();

    // }

    // function get_all_icons(page = 1) {
    //     $.ajax({
    //         url: "{route('get-all-icons-api')}",
    //         method: 'POST',
    //         data: {
    //             "_token": "{ csrf_token() }",
    //             "page": page,
    //         },
    //         success: function (response) {
    //             console.log(response.data)
    //             var html = "";
    //             var temp = "";
    //             response.data.forEach(icon => {
    //                 temp +=  `
    //                 <div style="position: relative;" class="col-md-4 col-lg-3 col-sm-6 col-xs-12" style="margin-top: 2rem">
    //                     <label>
    //                         <div class="card" style="height: 15rem m-1">
    //                             <img src="{{ env('APP_URL') }}/public/uploads/${ icon.file_name }"
    //                                 alt="" class="img-thumbnail"
    //                                 style="width: 100%; height: 10rem">
    //                                 <div class="card-body">
    //                                 <h5 class="card-title">${ icon.file_name }</h5>
    //                             </div>
    //                         </div>
    //                         <input type="radio" style="position: absolute;top:5%; left:10%; width: 2rem; height: 2rem;" id="${ icon.id }" name="icons" value="${ icon.file_name }">
    //                     </label>
    //                 </div>`;
    //             });

    //             html += temp
    //             $('#icons-listing').html(html)

    //             // Create pagination links dynamically
    //             var pagination_icons = '';
    //             for (var i = 1; i <= response.last_page; i++) {
    //                 pagination_icons += `<li class="page-item${i === response.current_page ? 'active' : ''}">
    //                                 <a class="page-link" href="javascript:void(0);" onclick="get_all_icons(${i})">${i}</a>
    //                                 </li>`;
    //             }

    //             $('#pagination-icons').html(pagination_icons);
    //         },
    //         error: function (xhr) {
    //             console.log('smth')
    //             console.log(xhr);
    //         }
    //     });
    // }

</script>