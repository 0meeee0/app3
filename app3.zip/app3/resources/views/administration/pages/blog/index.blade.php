@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Blogs'])



    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card py-4">
                
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="mb-0">Blogs</h5>
                        <a href="{{route('blog.create')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Ajouter un Blog</a>
                    </div>

                    {{-- Include Alert --}}
                    @include('administration.components.SessionAlerts')
                    <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-height fixed-columns">
                        <div class="dataTable-top">
                            {{-- <div class="dataTable-dropdown">
                                <label>
                                    <select class="dataTable-selector">
                                        <option value="5">5</option>
                                        <option value="10" selected="">10</option>
                                        <option value="15">15</option>
                                        <option value="20">20</option>
                                        <option value="25">25</option>
                                    </select> entries per page
                                </label>
                            </div> --}}
                        <div class="dataTable-search">
                            <form action="{{route('blog.index')}}" method="get" class="d-flex">
                                @csrf
                                <input class="dataTable-input form-control m-0 mx-2" placeholder="Cherche..." name="search" type="text" required>
                                <button type="submit" class="btn btn-primary m-0">Cherche</button>
                            </form>
                        </div>
                    </div>
                    <div class="dataTable-container p-2" style="overflow: auto">
                        <table class="table table-flush dataTable-table" id="datatable-basic">
                            <thead class="thead-light">
                                <tr>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 11.5227%;">
                                        <a href="#" class="dataTable-sorter">
                                            titre
                                        </a>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 24.9232%;">
                                        Photo
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 11.0106%;">
                                        <a href="#" class="dataTable-sorter">
                                            Description
                                        </a>
                                    </th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 20.9969%;">
                                        <a href="#" class="dataTable-sorter">
                                            Date
                                        </a>
                                    </th>
                                    {{-- <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 19.8873%;">
                                        <a href="#" class="dataTable-sorter">
                                        Creation Date
                                    </a></th> --}}
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 11.6934%;">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($blogs as $item)
                                    @php
                                        $img = \App\Models\Image::findOrFail($item->banner_id);
                                    @endphp
                                    <tr>
                                        <td class="text-sm font-weight-normal">{{$item->title}}</td>
                                        <td class="text-sm font-weight-normal">
                                            <span class="my-2 text-xs">
                                                <img src="{{env('APP_URL')}}/public/uploads/{{$img->file_name}}" alt="Blog" class="border-radius-lg shadow-sm height-100 w-auto">
                                            </span>
                                        </td>
                                        <td class="text-sm font-weight-normal td_title">
                                            {{$item->description}}
                                        </td>
                                        <td class="text-sm font-weight-normal">2023-07-19 12:00:09</td><td class="text-sm">
                                            <span class="d-flex">
                                                <a href="{{route('blog.edit', ['blog' => $item->id ])}}" class="me-3" data-bs-toggle="tooltip" data-bs-original-title="Edit item">
                                                    <i class="fas fa-user-edit text-secondary" aria-hidden="true"></i>
                                                </a>
                                                <form action="{{route('blog.destroy', ['blog' => $item->id ])}}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button data-bs-toggle="tooltip" data-bs-original-title="Delete item" class="border-0 bg-white">
                                                        <i class="fas fa-trash text-secondary" aria-hidden="true"></i>
                                                    </button>
                                                </form>
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        @include('administration.layouts.footers.auth.footer')
    </div>

@endsection