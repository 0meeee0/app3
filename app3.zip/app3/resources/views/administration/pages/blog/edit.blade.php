@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Blog'])

    <div class="container-fluid py-4">
        <div class="row mb-5">
            <div class="col-lg-9 col-12 mx-auto">
                <div class="card card-body mt-4">
                    <h6 class="mb-0">Modifier blog</h6>
                    <hr class="horizontal dark my-3">

                    @include('administration.components.SessionAlerts')

                    <form method="POST" action="{{ route('blog.update', ['blog' => $blog->id]) }}"  class="needs-validation" novalidate>
                        @csrf
                        @method('PUT')

                        <label for="name" class="form-label"> Titre</label>
                        <div class="mb-3">
                            <input type="text" class="form-control" name="title" onfocus="focused(this)"
                                onfocusout="defocused(this)" value="{{$blog->title ?? ''}}" required>
                        </div>
                        <label for="name" class="form-label"> Categorie</label>
                        <div class="mb-3">
                            <select name="category_id" class="form-control">
                                @foreach ($categories as $item)
                                    @if ($item->id == $blog->category_id)                                    
                                        <option value="{{$item->id}}" selected>{{$item->title}}</option>
                                    @else
                                        <option value="{{$item->id}}">{{$item->title}}</option>
                                    @endif
                                @endforeach
                            </select>
                        </div>

                        <label class="mt-4"> Description</label>
                        <textarea name="description" rows="7" class="w-100 form-control"  required>{{$blog->description ?? ''}}</textarea>



                        <label class="mt-4">Images</label>
                        <div class="input-group mb-3">
                            <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                            <input type="text" class="form-control" placeholder=""
                                aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                        </div>

                        @php
                            $img = \App\Models\Image::findOrFail($blog->banner_id)
                        @endphp

                        <div class="images-thumb d-flex" id="images-thumb">
                            <div class='p-2' id='{{$blog->banner_id}}'><img src='{{env('APP_URL')}}/public/uploads/{{$img->file_name}}' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'></div>
                        </div>
                        <div id="selected_images">
                            <input type='hidden' name='selecteImages' value="{{$blog->banner_id}}">
                        </div>

                        <label class="mt-4"> Content</label>
                        <textarea id="editor"  name="content" rows="10" class="w-100 form-control">{{$blog->content ?? ''}}</textarea>

                        <div class="d-flex justify-content-end mt-4">
                            <a href="{{ route('blog.index') }}">
                                <button type="button" class="btn bg-gradient-primary m-0 ms-2">Annuler</button>
                            </a>
                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
        
        <script type="text/javascript">
            // JavaScript to add validation styling to the form
            // (Assuming you have included Bootstrap's JS library)
            (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
            })();
        </script>
    </div>
@endsection
