@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Service'])

    <div class="container-fluid py-4">
        <div class="row mb-5">
            <div class="col-lg-9 col-12 mx-auto">
                <div class="card card-body mt-4">
                    <h6 class="mb-0">Modifier Service</h6>
                    <hr class="horizontal dark my-3">

                    @include('administration.components.SessionAlerts')

                    <form method="POST" action="{{ route('services.update', ['service' => $service->id]) }}"  class="needs-validation" enctype="multipart/form-data" novalidate>
                        @csrf
                        @method('PUT')
                        <label for="name" class="form-label"> Titre</label>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="name" name="title" value="{{$service->title}}" onfocus="focused(this)"
                                onfocusout="defocused(this)" required>
                        </div>
                        <label class="mt-4"> Courte description</label>
                        <textarea name="short_description" rows="1" class="w-100 form-control" required>{{$service->short_description}}</textarea>

                        <label class="mt-4"> Description (Meta)</label>
                        <textarea name="description" id="editor" rows="7" class="w-100 form-control"  required>{{$service->description}}</textarea>
                        <p> max 150 litres</p>


                        <label class="mt-4">Banner</label>
                        <div class="input-group mb-3">
                            <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                            <input type="text" class="form-control" placeholder=""
                                aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                        </div>

                        <div class="images-thumb d-flex" id="images-thumb">
                            <div class='p-2' id='{{$service->img_id}}'><img src='{{env('APP_URL')}}/public/uploads/{{$service->file_name}}' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'></div>
                        </div>
                        <div id="selected_images">
                            <input type='hidden' name='selecteImages' value="{{$service->img_id}}">
                        </div>

                        <label class="mt-4">Images</label>
                        <div class="input-group mb-3">
                            <input type="file" class="form-control" id="imageInput" name="images[]"
                               aria-describedby="button-addon1" multiple>
                        </div>
                        <div id="imagePreview" class="d-flex flex-wrap">
                            @if ($service->images)
                                @foreach (json_decode($service->images) as $img)
                                    <div class="img-edit position-relative m-1 p-0">
                                        <img src="{{ asset('storage/app/public/uploads/services/' . $img) }}" style="width: 200px;height: 200px;">
                                        <span class="text-white close-image" data-image-name="{{ $img }}" style="
                                                position: absolute;
                                                top: -5px;
                                                font-size: 2rem;
                                                left: 10px;
                                                cursor: pointer;
                                                ">&times;</span>
                                    </div>
                                @endforeach
                            @endif
                        </div>      
                        <input type="hidden" name="deletedImages" id="deletedImagesInput" value="">
                        <div class="d-flex justify-content-end mt-4">
                            <a href="{{ route('services.index') }}">
                                <button type="button" class="btn bg-gradient-primary m-0 ms-2">Annuler</button>
                            </a>
                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
        
        <script type="text/javascript">
            // JavaScript to add validation styling to the form
            // (Assuming you have included Bootstrap's JS library)
            (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
            })();

            $(document).ready(function () {
                var deletedImages = []; // Array to store deleted image names

                $(".close-image").on("click", function () {
                    var imageName = $(this).data("image-name");
                    var imageContainer = $(this).parent();

                    // Remove the image container from the DOM
                    imageContainer.remove();

                    // Add the deleted image name to the array
                    deletedImages.push(imageName);

                    // Update the value of the hidden input field
                    $("#deletedImagesInput").val(JSON.stringify(deletedImages));
                });
            });

            const input = document.getElementById('imageInput');
            const preview = document.getElementById('imagePreview');

            input.addEventListener('change', () => {
                const fileListArr = Array.from(input.files);

                fileListArr.forEach((file, index) => {
                    const reader = new FileReader();

                    reader.onload = function (e) {
                        const imgContainer = document.createElement('div');
                        imgContainer.className = 'img-edit position-relative m-1 p-0';

                        const image = document.createElement('img');
                        image.src = e.target.result;
                        image.style.height = '200px';
                        image.style.width = '200px';

                        const closeButton = document.createElement('span');
                        closeButton.className = 'text-white close-image';
                        closeButton.innerHTML = '&times;';
                        closeButton.style.position = 'absolute';
                        closeButton.style.top = '-5px';
                        closeButton.style.fontSize = '2rem';
                        closeButton.style.left = '10px';
                        closeButton.style.cursor = 'pointer';

                        imgContainer.appendChild(image);
                        imgContainer.appendChild(closeButton);
                        preview.appendChild(imgContainer);

                        closeButton.addEventListener('click', () => {
                            // Remove the image container from the preview
                            preview.removeChild(imgContainer);

                            // Remove the file from the fileListArr
                            fileListArr.splice(index, 1);
                        });
                    };

                    reader.readAsDataURL(file);
                });
            });
        </script>
    </div>
@endsection
