@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Services'])

    <div class="container-fluid py-4">
        <div class="row mb-5">
            <div class="col-lg-12 col-12 mx-auto">
                <div class="card card-body mt-4">
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="mb-0">Service</h5>
                        <a data-bs-toggle="modal" data-bs-target="#dropzoneCheck" class="btn bg-gradient-dark btn-sm float-end mb-0">Ajouter des imgaes</a>
                    </div>

                    @include('administration.components.SessionAlerts')

                    <div class="row px-3" id="images_row">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
<div class="modal fade" id="dropzoneCheck" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-light">

                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active my-btn-refresh" id="nav-home-tab" data-bs-toggle="tab"
                            data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                            aria-selected="true">Choisir</button>
                        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab"
                            data-bs-target="#nav-profile" type="button" role="tab"
                            aria-controls="nav-profile" aria-selected="false">Télécharger nouveau</button>
                    </div>
                </nav>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                        aria-labelledby="nav-home-tab" tabindex="0">
                        <div class="image-select p-3">
                            <div class="image-select-header d-flex">
                                <div class="image-select-header-filter w-25">
                                    
                                </div>
                                <div class="image-select-header-search ">
                                    <div class="modal-search">
                                        <input class="search-input" placeholder="Search..." type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="image-select-body row" id="images-listing"></div>
                            <nav aria-label="Page navigation">
                                <ul class="pagination" id="pagination">
                                    <!-- Pagination links will be generated dynamically here -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel"
                        aria-labelledby="nav-profile-tab" tabindex="0">
                        <div class="p-3 image-drop">
                            <form action="{{ route('upload') }}" method="post" enctype="multipart/form-data"
                                id="dropzone" class="dropzone" >
                                @csrf
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                <button id='select-selected-images' type="button" class="btn btn-primary" onclick="save_changes_modal()">Sauvegarder</button>
            </div>
        </div>
    </div>
</div>
{{-- End Modal --}}
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                loadImages();
                get_all_images();

            });
    
            var dropzone = new Dropzone('#dropzone', {
                thumbnailWidth: 400,
                maxFilesize: 25,
                acceptedFiles: ".jpeg,.jpg,.png,.gif,.webp",
            });
            
            // Add a success event listener
            dropzone.on('success', function(file, response) {
                get_all_images(); 
            });
                
            function save_changes_modal() {
                
                const checkboxes = document.querySelectorAll('input[name="images"]:checked');
                
                // Initialize an array to store the IDs and values as objects
                const selectedItems = [];
                
                // Loop through the checked checkboxes and extract the information
                checkboxes.forEach((checkbox) => {
                    const id = checkbox.id;
                    const name = checkbox.value;
                    selectedItems.push({ id, name });
                });
                console.log(selectedItems);
                
                var selected_images_inputs = "";
                var images_thumb = "";
                
                var img_num = 0;

                selectedItems.forEach(element => {
                    selected_images_inputs += "<input type='hidden' name='selecteImages' value='" + element.id + "' >";
                    images_thumb += "<div class='p-2' id='" + element.id + "'><img src='{{env('APP_URL')}}/public/uploads/" + element.name + "' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'></div>";
                    img_num++;
                });

                $('#selected_images_input_value_mutli').val("  " + img_num + " Fichiers sélectionnés");

                $('#selected_images_multi').html(selected_images_inputs);
                // $('#images-thumb').html(images_thumb);

                $.ajax({
                    url: "{{route('add_service_images', ['service' => $service->id])}}",
                    method: 'POST',
                    data: {
                        "_token": "{{ csrf_token() }}",
                        "images": selectedItems.map(item => item.id), // Send an array of selected image IDs
                    },
                    success: function (response) {
                        loadImages();
                    },
                    error: function (xhr) {
                        console.log(xhr.responseText);
                    }
                });
                checkboxes.forEach(checkbox => {
                    checkbox.checked = false;
                });

                $('#dropzoneCheck').modal('hide');
                $('body').removeClass('model-open');
                $('.modal-backdrop').remove();
                
            };

            function get_all_images(page = 1) {
                $.ajax({
                    url: "{{route('get-all-images-api')}}",
                    method: 'POST',
                    data: {
                        "_token": "{{ csrf_token() }}",
                        "page": page,
                    },
                    success: function (response) {
                        // console.log(response)
                        var html = "";
                        var temp = "";
                        response.data.forEach(img => {
                            temp +=  `
                            <div style="position: relative;" class="col-md-4 col-lg-3 col-sm-6 col-xs-12" style="margin-top: 2rem">
                                <label>
                                    <div class="card" style="height: 15rem m-1">
                                        <img src="{{ env('APP_URL') }}/public/uploads/${ img.file_name }"
                                            alt="" class="img-thumbnail"
                                            style="width: 100%; height: 10rem">
                                            <div class="card-body">
                                            <h5 class="card-title">${ img.file_name }</h5>
                                        </div>
                                    </div>
                                    <input type="checkbox" style="position: absolute;top:5%; left:10%; width: 2rem; height: 2rem;" id="${ img.id }" name="images" value="${ img.file_name }">
                                </label>
                            </div>`;
                        });

                        html += temp
                        $('#images-listing').html(html)

                        // Create pagination links dynamically
                        var pagination = '';
                        for (var i = 1; i <= response.last_page; i++) {
                            pagination += `<li class="page-item ${i === response.current_page ? 'active' : ''}">
                                            <a class="page-link" href="javascript:void(0);" onclick="get_all_images(${i})">${i}</a>
                                            </li>`;
                        }

                        $('#pagination').html(pagination);
                    },
                    error: function (xhr) {
                        // console.log(xhr);
                    }
                });
            }

            function loadImages(){
                $.ajax({
                    url: "{{route('get_service_images', ['service' => $service->id])}}",
                    method: "post",
                    data: {
                        "_token": "{{ csrf_token() }}",
                    },
                    success: function (response) {
                        console.log(response);
                        var html = "";
                        response.forEach(img => {
                            var formAction = "{{ route('remove-image-service', ['service' => ':id']) }}";
                            formAction = formAction.replace(':id', img.id);  
                            
                            var imageHtml = `
                            <div class="col-12 col-sm-6 col-md-6 p-1 position-relative">
                                <form action="${formAction}" method="post" style="top: 1rem; right: 1rem;" class="position-absolute">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="bg-transparent rounded-circle fs-2" style="color: #fff; border: none">
                                        <i class="ni ni-fat-remove"></i>
                                    </button>
                                </form>
                                <img src="{{ env('APP_URL') }}/public/uploads/${img.file_name}" class="w-100 img-fluid rounded">
                            </div>`;
                            
                            html += imageHtml;
                        });
                        $('#images_row').html(html);
                    },
                    error: function (xhr) {
                        console.log(xhr.responseText);
                    }
                });
            }
        </script>
        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection
