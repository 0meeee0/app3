@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Réalisations'])
    <div class="container-fluid py-4">
        <div class="container-fluid py-4">
            <div class="row mb-5">
                <div class="col-lg-9 col-12 mx-auto">
                    <div class="card card-body mt-4">
                        <h6 class="mb-0">Modifer Réalisations</h6>
                        <hr class="horizontal dark my-3">
    
                        @include('administration.components.SessionAlerts')
    
                        <form method="POST" action="{{ route('portfolio.update', ['portfolio' => $project->id]) }}"  class="needs-validation" novalidate>
                            @csrf
                            @method('PUT')
                            <label for="name" class="form-label"> Titre</label>
                            <div class="mb-3">
                                <input type="text" class="form-control" id="name" name="title" onfocus="focused(this)"
                                    onfocusout="defocused(this)" value="{{$project->titre}}" required>
                            </div>
                            <label class="mt-4"> Courte description</label>
                            <textarea name="short_description" rows="2" class="w-100 form-control" required>{{$project->short_description}}</textarea>
    
                            <label class="mt-4"> Description</label>
                            <textarea name="description" rows="7" class="w-100 form-control"  required>{{$project->description}}</textarea>
    
    
                            <label class="mt-4">Images</label>
                            <div class="input-group mb-3">
                                <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                    data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                                <input type="text" class="form-control" placeholder=""
                                    aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                            </div>
                            <div class="images-thumb d-flex" id="images-thumb">
                                <div class='p-2' id='" + element.id + "'>
                                    @php
                                        $img = \App\Models\Image::find($project->banner_id);
                                    @endphp
                                    <img src='{{env('APP_URL')}}/public/uploads/{{$img->file_name}}' style='width:80px;height:80px;box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);border-radius: 10px;'>
                                </div>
                            </div>
    
                            <label class="mt-4"> Content</label>
                            <textarea id="editor"  name="content" class="w-100 form-control">{{$project->content}}</textarea>

                            <div id="selected_images">
                                <input type='hidden' name='selecteImages' value="{{$img->id}}" >
                            </div>
    
                            <div class="d-flex justify-content-end mt-4">
                                <a href="{{ route('portfolio.index') }}">
                                    <button type="button" class="btn bg-gradient-primary m-0 ms-2">Annuler</button>
                                </a>
                                <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- Modal -->
            <div class="modal fade" id="dropzoneCheck" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header bg-light">

                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active my-btn-refresh" id="nav-home-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                                        aria-selected="true">Choisir</button>
                                    <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab"
                                        data-bs-target="#nav-profile" type="button" role="tab"
                                        aria-controls="nav-profile" aria-selected="false">Télécharger nouveau</button>
                                </div>
                            </nav>

                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                                    aria-labelledby="nav-home-tab" tabindex="0">
                                    <div class="image-select p-3">
                                        <div class="image-select-header d-flex">
                                            <div class="image-select-header-filter w-25">
                                                
                                            </div>
                                            <div class="image-select-header-search ">
                                                <div class="modal-search">
                                                    <input class="search-input" placeholder="Search..." type="text">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="image-select-body row" id="images-listing"></div>
                                        <nav aria-label="Page navigation">
                                            <ul class="pagination" id="pagination">
                                                <!-- Pagination links will be generated dynamically here -->
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-profile" role="tabpanel"
                                    aria-labelledby="nav-profile-tab" tabindex="0">
                                    <div class="p-3 image-drop">
                                        <form action="{{ route('upload') }}" method="post" enctype="multipart/form-data"
                                            id="dropzone" class="dropzone" >
                                            @csrf
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer bg-light">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button id='select-selected-images' type="button" class="btn btn-primary" onclick="save_changes_modal()">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
            @include('administration.components.dropzone')   
        @include('administration.layouts.footers.auth.footer')
        <script type="text/javascript">
            // JavaScript to add validation styling to the form
            // (Assuming you have included Bootstrap's JS library)
            (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
            })();

            document.addEventListener("DOMContentLoaded", function () {
                CKEDITOR.replace("editor");
            });
            
            
            
        </script>
    </div>
</div>
@endsection
