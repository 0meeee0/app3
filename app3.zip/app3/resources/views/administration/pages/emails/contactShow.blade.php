@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Contact'])



    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center">

                <div class="col-12 col-md-12 col-lg-8 col-xl-7 mt-md-0 mt-4">
                    <div class="card h-100">
                        <div class="card-header pb-0 p-4">
                            <div class="row">
                                <div class="w-100 d-flex align-items-center justify-content-center">
                                    <h4 class="mb-0">Email du contact</h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-3">
                            <hr class="horizontal gray-light my-4">
                            <ul class="list-group">
                                <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark mx-2">
                                    Full Name:</strong> {{$contact->name}}</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Mobile:</strong> {{$contact->phone}}</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Email:</strong> {{$contact->email}}    
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Date:</strong> {{ \Carbon\Carbon::parse($contact->created_at)->format('d/m/Y') }} 
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm">
                                    <strong class="text-dark mx-2">Message:</strong>
                                    <p class="p-3">
                                        {{$contact->message}} 
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        @include('administration.layouts.footers.auth.footer')


        <script></script>
    </div>
@endsection
