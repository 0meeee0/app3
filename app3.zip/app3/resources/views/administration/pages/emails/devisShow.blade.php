@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Devis'])



    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12 d-flex justify-content-center">

                <div class="col-12 col-md-12 col-lg-8 col-xl-7 mt-md-0 mt-4">
                    <div class="card h-100">
                        <div class="card-header pb-0 p-4">
                            <div class="row">
                                <div class="w-100 d-flex align-items-center justify-content-center">
                                    <h4 class="mb-0">Email du Devis</h4>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-3">
                            <hr class="horizontal gray-light my-4">
                            <ul class="list-group">
                                <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark mx-2">
                                    Société:</strong> {{$devis->societe}}</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Email:</strong> {{$devis->email}}    
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Mobile:</strong> {{$devis->phone}}</li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Date:</strong> {{ \Carbon\Carbon::parse($devis->created_at)->format('d/m/Y') }} 
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Adresse:</strong> {{$devis->adress}} 
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Code Postal:</strong> {{$devis->codePostal}} 
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark mx-2">
                                    Ville:</strong> {{$devis->ville}} 
                                </li>
                                <li class="list-group-item border-0 ps-0 text-sm">
                                    <strong class="text-dark mx-2">Demande:</strong>
                                    <p class="p-3">
                                        {{$devis->demande}} 
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        @include('administration.layouts.footers.auth.footer')


        <script></script>
    </div>
@endsection
