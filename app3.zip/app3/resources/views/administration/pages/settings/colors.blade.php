@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Couleur'])
    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">

                @include('administration.components.SessionAlerts')
                <div class="row mb-3 d-flex justify-content-center">

                    <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex">
                        <div class="card flex-fill mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">Paramètres</h5>
                            </div>
                            <div class="card-body pt-2 px-5">
                                <div class="table-responsive">
                                    <form action="{{route('settings-colors-update')}}" method="post">
                                        @csrf
                                        @method('PATCH')

                                        <label class="mt-1">Background Color</label>
                                        <div class="mb-3">
                                            <input type="color" id="head" name="back_color" class="form-control" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$settings->back_color ?? '#111'}}" >
                                            <div class="invalid-feedback">Veuillez saisir une couleur.</div>
                                        </div>

                                        <label class="mt-1">Background Color</label>
                                        <div class="mb-3">
                                            <input type="color" id="primary" name="primary_color" class="form-control" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$settings->primary_color ?? ''}}" >
                                            <div class="invalid-feedback">Veuillez saisir une couleur.</div>
                                        </div>

                                        <div class="d-flex justify-content-end mt-3">
                                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection
