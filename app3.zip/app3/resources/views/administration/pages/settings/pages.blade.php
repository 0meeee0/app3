@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Paramètres'])
    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">

                @include('administration.components.SessionAlerts')
                <div class="row mb-3 d-flex justify-content-center">
                    {{-- Start about us --}}
                    <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex">
                        <div class="card flex-fill mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">Paramètres</h5>
                            </div>
                            <div class="card-body pt-0">
                                <div class="table-responsive">
                                    <form action="{{route('settings-pages-update')}}" method="post">
                                        @csrf
                                        @method('PUT')
                                        <table class="table mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="ps-1" colspan="4">
                                                        <p class="mb-0">Page</p>
                                                    </th>
                                                    <th class="text-center">
                                                        <p class="mb-0">Visible</p>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">À propos</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "À propos" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="about_page" {{$settings->is_about_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">Services</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "Services" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="service_page"  {{$settings->is_service_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">Portfolio</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "Portfolio" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="portfolio_page"  {{$settings->is_portfolio_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">Blog</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "Blog" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="blog_page"  {{$settings->is_blog_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">Contact</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "Contact" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="contact_page"  {{$settings->is_contact_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="ps-1" colspan="4">
                                                        <div class="my-auto">
                                                            <span class="text-dark d-block text-sm">Devis</span>
                                                            <span class="text-xs font-weight-normal">
                                                                Si désactivé, page "Devis" invisible.</span>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
                                                            <input class="form-check-input" type="checkbox" name="devis_page"  {{$settings->is_devis_section ? 'checked' : '' }}>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                        <div class="d-flex justify-content-end mt-3">
                                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- End about us --}}
                </div>

            </div>
        </div>



        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection
