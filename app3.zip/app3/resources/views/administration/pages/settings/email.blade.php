@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Configuration address émail'])
    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">

                @include('administration.components.SessionAlerts')
                <div class="row mb-3 d-flex justify-content-center">
                    {{-- Start about us --}}
                    <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex">
                        <div class="card flex-fill mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">Paramètres</h5>
                            </div>
                            <div class="card-body pt-0">
                                <div class="table-responsive">
                                    <form action="{{route('settings-pages-update')}}" method="post">
                                        @csrf
                                        @method('PUT')
                                        <div class="d-flex align-items-center justify-content-center py-5">
                                            <img src="{{env('APP_URL')}}/public/assets/img/sorry.svg" style="height: 300px;width:auto;">
                                            <p>Cette page est actuellement indisponible !</p>
                                        </div>

                                        <div class="d-flex justify-content-end mt-3">
                                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- End about us --}}
                </div>

            </div>
        </div>



        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection
