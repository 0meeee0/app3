@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Blog Catégories'])



    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12">
                <div class="card py-4">
                
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="mb-0">Blog Catégories</h5>
                        <a href="{{route('blog-category.create')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Ajouter une Catégorie</a>
                    </div>

                    {{-- Include Alerts --}}
                    @include('administration.components.SessionAlerts')
                    <div class="table-responsive">
                        <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-height fixed-columns">
                            <div class="dataTable-top">
                                <div class="dataTable-dropdown">
                                    <label>
                                        <select class="dataTable-selector">
                                            <option value="5">5</option>
                                            <option value="10" selected="">10</option>
                                            <option value="15">15</option>
                                            <option value="20">20</option>
                                            <option value="25">25</option>
                                        </select> entries per page
                                    </label>
                                </div>
                                {{-- <div class="dataTable-search">
                                    <input class="dataTable-input" placeholder="Search..." type="text">
                                </div> --}}
                            </div>
                            <div class="dataTable-container">
                                <table class="table table-flush dataTable-table" id="datatable-basic">
                                    <thead class="thead-light">
                                        <tr>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 15.0623%;">
                                                <a href="#" class="dataTable-sorter">
                                                    Titre
                                                </a>
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 44.0088%;"><a href="#" class="dataTable-sorter">
                                                Description
                                                </a>
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 27.4318%;"><a href="#" class="dataTable-sorter">
                                                Date de Creation
                                                </a>
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 13.4635%;">
                                                Action
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="mb-4">
                                        @foreach ($categories as $item)
                                            <tr>
                                                <td class="text-sm font-weight-normal">{{$item->title}}</td>
                                                <td class="text-sm font-weight-normal td_title">{{$item->description}}</td>
                                                <td class="text-sm font-weight-normal">{{$item->created_at}}</td>
                                                <td class="text-sm">
                                                    <span class="d-flex">
                                                        <a href="{{route('blog-category.edit', ['blog_category' => $item->id])}}" class="me-3" data-bs-toggle="tooltip" data-bs-original-title="Edit category">
                                                            <i class="fas fa-user-edit text-secondary" aria-hidden="true"></i>
                                                        </a>
                                                        <form action="{{route('blog-category.destroy', ['blog_category' => $item->id])}}" method="post">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button {{-- onclick="confirm('Are you sure you want to remove the category?') || event.stopImmediatePropagation()" --}} data-bs-toggle="tooltip" data-bs-original-title="Delete category" class="border-0 bg-white">
                                                                <i class="fas fa-trash text-secondary" aria-hidden="true"></i>
                                                            </button>
                                                        </form>
                                                    </span>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @include('administration.layouts.footers.auth.footer')
        <script>
            
        </script>
    </div>

@endsection