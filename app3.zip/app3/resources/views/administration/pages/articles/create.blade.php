@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Articles'])
    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">
                <form action="{{ route('article.store') }}" method="post" class="needs-validation" onsubmit="return validateFormImage()" novalidate>
                    @csrf
                    @include('administration.components.SessionAlerts')
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                            <div class="card mb-3">
                    
                                <div class="card-header d-flex justify-content-between">
                                    <h5 class="mb-0">Ajouter une catégorie</h5>
                                    {{-- <a href="{{route('category.')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Add Category</a> --}}
                                    <hr class="horizontal dark my-3">
                                </div>

                                <div class="container px-3 pt-0 pb-4">
                                    
                                    <label for="name" class="form-label">Titre</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" id="name" name="title" onfocus="focused(this)" onfocusout="defocused(this)" required>
                                        <div class="invalid-feedback">Veuillez saisir un titre.</div>
                                    </div>
                                    <label class="mt-4">Categorie</label>
                                    @php
                                        $categories = \App\Models\Category::get_all();
                                    @endphp
                                    <select class="form-select" name="category_id" >
                                        <option selected>Sélectionner une catégorie</option>
                                        @foreach ($categories as $item)
                                            <option value="{{$item->id}}">{{$item->title}}</option>
                                        @endforeach
                                    </select>
                                      
                                      
                                

                                    <label class="mt-4">Courte description</label>
                                    <textarea name="short_description" rows="2" class="w-100 form-control" required></textarea>
                                    <div class="invalid-feedback">Veuillez saisir une courte description</div>
                                
                                    <label class="mt-4">Description</label>
                                    <textarea id="editor" name="description" rows="7" class="w-100 form-control" required></textarea>
                                    <div class="invalid-feedback">Veuillez saisir une description</div>
                                    <div id="selected_images_radio"></div>
                                    <div id="selected_images"></div>
                                </div>
    
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-md-4 col-lg-4">

                            <div class="card mb-3">
                                <div class="card-header d-flex justify-content-between">
                                    <h5 class="mb-0">Status</h5>
                                    {{-- <a href="{{route('category.')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Add Category</a> --}}
                                    <hr class="horizontal dark my-3">
                                </div>
                                <div class="container px-3 pt-0 pb-4">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" name="publie" type="checkbox" id="Publie" value="1" checked>
                                        <label class="form-check-label" for="Publie">Publié</label>
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header d-flex justify-content-between pb-0">
                                    <h5 class="mb-0">Images</h5>
                                    {{-- <a href="{{route('category.')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Add Category</a> --}}
                                    <hr class="horizontal dark my-3">
                                </div>
                                <div class="container px-3 pt-0">
                                    <label class="mt-4">Miniature</label>
                                    <div class="input-group">
                                        <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                            data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                                        <input type="text" class="form-control" placeholder=""
                                            aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                                    
                                        <div class="invalid-feedback-images">Veuillez sélectionner une image</div>
                                    </div>

                                    <div class="images-thumb d-flex" id="images-thumb"></div>

                                </div>
                               
                                
                            </div>

                            
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-end mt-4">
                        <a href="{{ route('article.index') }}">
                            <button type="button" class="btn bg-gradient-primary m-0 ms-2">Retour</button>
                        </a>
                        <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Ajouter</button>
                    </div>
                
                </form>
            </div>
        </div>
        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
        
        <script>
    
            function validateFormImage() {
                var selectedImagesDiv = document.getElementById("selected_images");
                var errorMessageDiv = document.querySelector(".invalid-feedback-images");

                if (selectedImagesDiv.innerHTML.trim() === "") {
                    // If the div is empty, show the error message and prevent form submission
                    errorMessageDiv.style.display = "block";
                    return false;
                } else {
                    // If the div is not empty, hide the error message and allow form submission
                    errorMessageDiv.style.display = "none";
                    return true;
                }
            }
            // JavaScript to add validation styling to the form
            // (Assuming you have included Bootstrap's JS library)
            (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
            })();
            
        </script>

        
    </div>
@endsection
