@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Articles'])

    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">
                <div class="card pb-3">
                
                    <div class="card-header d-flex justify-content-between">
                        <h5 class="mb-0">Articles</h5>
                        <a href="{{route('article.create')}}" class="btn bg-gradient-dark btn-sm float-end mb-0">Ajouter Nouveau</a>
                    </div>
                    @include('administration.components.SessionAlerts')
                    <div class="table-responsive">
                        <div class="dataTable-wrapper dataTable-loading no-footer sortable searchable fixed-height fixed-columns">
                            <div class="dataTable-top">
                                <div class="dataTable-dropdown">
                                    <label>
                                        <select class="dataTable-selector">
                                            <option value="5">5</option>
                                            <option value="10" selected="">10</option>
                                            <option value="15">15</option>
                                            <option value="20">20</option>
                                            <option value="25">25</option>
                                        </select> entries per page
                                    </label>
                                </div>
                            {{-- <div class="dataTable-search">
                                <input class="dataTable-input" placeholder="Search..." type="text">
                            </div> --}}
                        </div>
                        <div class="dataTable-container" style="height: 415.038px;">
                            <table class="table table-flush dataTable-table" id="datatable-basic">
                                <thead class="thead-light">
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 11.5227%;">
                                            <a href="#" class="dataTable-sorter">
                                                Name
                                            </a>
                                        </th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 24.9232%;">
                                            Photo
                                        </th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 11.0106%;">
                                            <a href="#" class="dataTable-sorter">
                                                Date
                                            </a>
                                        </th>
                                        
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 11.6934%;">
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($articles as $item)
                                        
                                    
                                        <tr>
                                            <td class="text-sm font-weight-normal">{{$item->title}}</td><td class="text-sm font-weight-normal">
                                                <span class="my-2 text-xs">
                                                    <img src="{{env('APP_URL')}}/public/uploads/{{$item->file_name}}" alt="item" class="border-radius-lg shadow-sm height-100 w-auto">
                                                </span>
                                            </td>
                                            <td class="text-sm font-weight-normal">2023-07-19 12:00:09</td><td class="text-sm">
                                                <span class="d-flex">
                                                    <a href="{{route('article.edit', ['article' => $item->id ])}}" class="me-3" data-bs-toggle="tooltip" data-bs-original-title="Edit item">
                                                        <i class="fas fa-user-edit text-secondary" aria-hidden="true"></i>
                                                    </a>
                                                    <form action="{{route('article.destroy', ['article' => $item->id ])}}" method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button data-bs-toggle="tooltip" data-bs-original-title="Delete item" class="border-0 bg-white">
                                                            <i class="fas fa-trash text-secondary" aria-hidden="true"></i>
                                                        </button>
                                                    </form>
                                                </span>
                                            </td>
                                        </tr>

                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        {{-- <div class="dataTable-bottom">
                            <nav class="dataTable-pagination">
                                {{ $categories->links() }}
                            </nav>
                        </div> --}}
                    </div>
                </div>
                </div>
            </div>
        </div>
        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection
