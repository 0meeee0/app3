@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Contact'])
    @php
        $email_contact = \App\Http\Controllers\ContentController::get_contact_info_by_name('email_contact');  
        $adress = \App\Http\Controllers\ContentController::get_contact_info_by_name('adress');  
        $telephone = \App\Http\Controllers\ContentController::get_contact_info_by_name('telephone');  
        $telephone2 = \App\Http\Controllers\ContentController::get_contact_info_by_name('telephone2'); 
    @endphp


    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12">
                {{-- include Alert --}}
                @include('administration.components.SessionAlerts')
                <div class="row mb-3">
                    <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex flex-column">

                        {{-- Start contact content --}}
                        <div class="card flex-fill mb-3 py-3">
                            <form action="{{route('contact-update')}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="card-header d-flex justify-content-between py-0">
                                    <h5 class="mb-0">Contact-nous</h5>
                                </div>
                                <div class="container px-3 pt-3">
                                    <label class="mt-1">Text</label>
                                    <div class="mb-3">
                                        <textarea class="w-100 form-control" name="contact_title" rows="3" required>{{$contact_page['title'] ?? ''}}</textarea>
                                    </div>
                                    <label class="mt-1">Email Contact</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="contact_email" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$contact_page['email'] ?? ''}}">
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end mt-3 p-3">
                                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                </div>
                            </form>
                        </div>    
                        {{-- End contact content --}}

                        {{-- Start Devis content --}} 
                        <div class="card flex-fill mb-3 py-3">
                            <form action="{{route('devis-update')}}" method="post">
                                @csrf
                                @method('PUT')
                                <div class="card-header d-flex justify-content-between py-0">
                                    <h5 class="mb-0">Demande de Devis</h5>
                                </div>
                                <div class="container px-3 pt-3">
                                    <label class="mt-1">Text</label>
                                    <div class="mb-3">
                                        <textarea class="w-100 form-control" name="devis_title" rows="3" required>{{$devis_page['title'] ?? ''}}</textarea>
                                    </div>
                                    <label class="mt-1">Email Devis</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="devis_email" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$devis_page['email'] ?? ''}}">
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end mt-3 p-3">
                                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                </div>
                            </form>
                        </div>  
                        {{-- End Devis content --}}  

                    </div>
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4">

                        {{-- Start general information --}}
                        <div class="card mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">INFORMATIONS GÉNÉRALES</h5>
                            </div>
                            <div class="container px-3 pt-3">
                                <form action="{{route('info_generale_update')}}" method="post">    
                                    @csrf
                                    @method('PUT')
                                    <label class="mt-1">Email Contact</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="info[email_contact]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$email_contact ?? ''}}">
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                    <label class="mt-1">Adress</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="info[adress]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$adress ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                    <label class="mt-1">Téléphone</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="info[telephone]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$telephone ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                    <label class="mt-1">FIX</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="info[telephone2]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$telephone2 ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir une description.</div>
                                    </div>
                                    <div class="d-flex justify-content-end mt-3">
                                        <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        {{-- End general information --}}
                    </div>
                </div>
            </div>
        </div>
        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>
@endsection