@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'A propos'])
    <div class="container-fluid py-4">

        <div class="row mt-4">
            <div class="col-12">

                    @include('administration.components.SessionAlerts')
                    <div class="row mb-3 d-flex justify-content-center">
                        {{-- Start about us --}}
                        <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex">
                            <div class="card flex-fill mb-3 py-3">
                                <div class="card-header d-flex justify-content-between py-0">
                                    <h5 class="mb-0">A propos</h5>
                                </div>
                                <div class="container px-3 pt-3">
                                    <form action="{{route('about-us-update')}}" method="post">
                                        @csrf
                                        @method('PUT')

                                        <label class="mt-1">Titre</label>
                                        <div class="mb-3">
                                            <input type="text" class="form-control" name="title" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$about_us->title ?? ''}}" >
                                            <div class="invalid-feedback">Veuillez saisir une description.</div>
                                        </div>

                                        <label class="mt-1">Description</label>
                                        <div class="mb-3">
                                            <textarea class="w-100 form-control" name="description" rows="7" required>{{$about_us->description ?? ''}}</textarea>
                                        </div>
                                        <label class="mt-1">Ans d'expérience</label>
                                        <div class="mb-3">
                                            <input type="number" class="form-control" name="content" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$about_us->content ?? ''}}" >
                                            <div class="invalid-feedback">Veuillez saisir une description.</div>
                                        </div>

                                        <label class="mt-3">Banner</label>
                                        <div class="input-group mb-3">
                                            <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                            data-bs-toggle="modal" data-bs-target="#dropzoneCheck">Sélectionner</button>
                                            <input type="text" class="form-control" placeholder=""
                                            aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                                        </div>
                                        
                                        <div class="images-thumb d-flex" id="images-thumb"></div>
                                        <div id="selected_images"></div>
                                        
                                        <div class="d-flex justify-content-end mt-3">
                                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                        </div>
                                        
                                    </form>
                                </div>
                            </div>                            
                        </div>
                        {{-- End about us --}}
                    </div>
                
            </div>
        </div>



        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>

@endsection