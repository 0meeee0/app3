@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Partenaires'])

    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12">
                @include('administration.components.SessionAlerts')
                <div class="row mb-3 d-flex justify-content-center">
                    {{-- Start Partenaires  --}}
                    <div class="col-12 col-sm-12 col-md-6">
                        <div class="card py-4">
                
                            <div class="card-header d-flex justify-content-between">
                                <h5 class="mb-0">Nos Partenaires</h5>
                            </div>
                            <div class="dataTable-container p-2" style="overflow: auto">
                                <table class="table table-flush dataTable-table" id="datatable-basic">
                                    <thead class="thead-light">
                                        <tr>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="" style="width: 11.5227%;">
                                                <a href="#" class="dataTable-sorter">
                                                    Name
                                                </a>
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 24.9232%;">
                                                Photo
                                            </th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" data-sortable="false" style="width: 11.6934%;">
                                                Action
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($partners as $item)
                                            
                                        
                                            <tr>
                                                <td class="text-sm font-weight-normal">{{$item->name}}</td>
                                                <td class="text-sm font-weight-normal">
                                                    <span class="my-2 text-xs">
                                                        <img src="{{env('APP_URL')}}/public/assets/img/partners/{{$item->image}}" alt="item" class="border-radius-lg shadow-sm height-100 w-auto">
                                                    </span>
                                                </td>
                                                <td class="text-sm">
                                                    <span class="d-flex">
                                                        {{-- <a href="#" class="me-3" data-bs-toggle="tooltip" data-bs-original-title="Edit item">
                                                            <i class="fas fa-user-edit text-secondary" aria-hidden="true"></i>
                                                        </a> --}}
                                                        <form action="{{route('partners-destroy', ['partners' => $item->id ])}}" method="post">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button onclick="confirm('Are you sure you want to remove the item?') || event.stopImmediatePropagation()" data-bs-toggle="tooltip" data-bs-original-title="Delete item" class="border-0 bg-white">
                                                                <i class="fas fa-trash text-secondary" aria-hidden="true"></i>
                                                            </button>
                                                        </form>
                                                    </span>
                                                </td>
                                            </tr>
        
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6">
                        <div class="card flex-fill mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">Ajouter Partenaires</h5>
                            </div>
                            <div class="container px-3 pt-3">
                                <form action="{{route('partners-update')}}" method="post"  enctype="multipart/form-data">
                                    @csrf
                                    @method('PUT')

                                    <label class="mt-1">Nom</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="name" onfocus="focused(this)" onfocusout="defocused(this)" required>
                                        <div class="invalid-feedback">Veuillez saisir un description.</div>
                                    </div>
                                    <label class="mt-1">Description</label>
                                    <div class="mb-3">
                                        <textarea class="form-control" name="description" row="2" onfocus="focused(this)" onfocusout="defocused(this)"></textarea>
                                        <div class="invalid-feedback">Veuillez saisir un description.</div>
                                    </div>
                                    <label class="mt-1">Image</label>
                                    <div class="mb-3">
                                        <input type="file" class="form-control" name="image" onfocus="focused(this)" onfocusout="defocused(this)" required>
                                        <div class="invalid-feedback">Veuillez saisir un description.</div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-end mt-3">
                                        <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Ajouter</button>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>                            
                    </div>
                    {{-- End Partenaires --}}
                </div>
            </div>
        </div>

        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>

@endsection