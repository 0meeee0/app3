@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])
@php
$home_slide_1 = \App\Models\Content::where('type', '=', 'home_slide_1')->firstOrFail();
$home_slide_2 = \App\Models\Content::where('type', '=', 'home_slide_2')->firstOrFail();
$home_slide_3 = \App\Models\Content::where('type', '=', 'home_slide_3')->firstOrFail();
@endphp
@section('content')
@include('administration.layouts.navbars.auth.topnav', ['title' => 'Acceuil'])


<div class="container-fluid py-4">

    <div class="row mt-4">
        <div class="col-12">

            @include('administration.components.SessionAlerts')
            <div class="row mb-3">

                {{-- Start index text heder --}}
                <div class="col-12 col-sm-12 col-md-8 col-lg-8 d-flex position-relative">

                    <div class="card flex-fill mb-3">
                        <div class="card-header d-flex justify-content-between">
                            <h5 class="mb-0">Modifier Page d'accueil</h5>
                            <hr class="horizontal dark my-3">
                        </div>

                        <div class="container px-3 pt-0 pb-4 pb-5">
                            <form action="{{route('index-text-update')}}" method="post">
                                @csrf
                                @method('PUT')

                                <label class="mt-1">Titre</label>
                                <div class="mb-3">
                                    <input type="text" class="form-control" name="title" onfocus="focused(this)"
                                        onfocusout="defocused(this)" value="{{$index_text['title'] ?? ''}}">
                                    <div class="invalid-feedback">Veuillez saisir une description.</div>
                                </div>



                                <label for="name" class="form-label">Text</label>
                                <textarea name="description" rows="4" class="w-100 form-control mb-3"
                                    required>{{$index_text['description'] ?? ''}}</textarea>

                                <div class="d-flex justify-content-end position-absolute bottom-0 end-0 m-3">
                                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                {{-- End index text heder --}}

                {{-- Start Media section --}}
                <div class="col-12 col-sm-12 col-md-4 col-lg-4 d-flex">
                    <div class="card flex-fill mb-3 py-3">
                        <div class="card-header d-flex justify-content-between py-0">
                            <h5 class="mb-0">Media</h5>
                        </div>
                        <div class="container px-3 pt-3">
                            <form action="{{route('media-update')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')

                                {{-- Logo --}}
                                <label class="mt-3">Logo</label>
                                <div class="input-group mb-3">
                                    <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                        data-bs-toggle="modal"
                                        data-bs-target="#dropzoneImagesCheck">Sélectionner</button>
                                    <input type="text" class="form-control" placeholder=""
                                        aria-label="Example text with button addon" id="selected_images_input_value"
                                        aria-describedby="button-addon1" readonly>
                                        
                                </div>

                                <div class="images-thumb d-flex" id="images-thumb">
                                     <img style="    background: #eaecef; padding: 10px;
    border-radius: 10px;
    border: solid 1px #d2d6da;"  height="60" src="{{env('APP_URL')}}/public/uploads/{{$index_text['file_name']}}"/>
                                </div>
                                <div id="selected_images">
                                </div>

                                {{-- Favicon --}}
                                <label class="mt-3">Icon</label>
                                <div class="mb-1">
                                    <input type="file" name="icon" class="form-control" onfocus="focused(this)"
                                        onfocusout="defocused(this)">
                                    <div class="invalid-feedback">Veuillez selectionner une image.</div>
                                     <div class="icons-thumb d-flex" id="icons-thumb">
                                   <img style="    background: #eaecef;
    padding: 10px;
    border-radius: 10px;
    border: solid 1px #d2d6da;"  height="60" src="{{env('APP_URL')}}/public/assets/img/favicon/{{$settings->favicon}}"/>
                                </div>
                                </div>
                               

                                {{-- <label class="mt-3">Icon</label>
                               
                                <div class="input-group mb-3">
                                    <button class="btn btn-outline-secondary" type="button" id="button-addon2"
                                        data-bs-toggle="modal"
                                        data-bs-target="#dropzoneIconsCheck">Sélectionner</button>
                                    <input type="text" class="form-control" placeholder=""
                                        aria-label="Example text with button addon" id="selected_icon_input_value"
                                        aria-describedby="button-addon2" readonly>
                                </div>

                                <div class="icons-thumb d-flex" id="icons-thumb">
                                  
                                </div>
                                <div id="selected_icon">
                                </div> --}}

                                <label class="mt-3">Video 1</label>
                                <div class="mb-1">
                                    <input type="file" name="slide_1" accept="image/*,video/*" class="form-control"
                                        onfocus="focused(this)" onfocusout="defocused(this)">
                                    <div class="invalid-feedback">Veuillez selectionner une image/video.</div>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control" name="title_1" onfocus="focused(this)"
                                        placeholder="Titre" onfocusout="defocused(this)"
                                        value="{{$home_slide_1['title'] ?? ''}}">
                                    <div class="invalid-feedback">Veuillez saisir une titre.</div>
                                </div>

                                <label class="mt-3">Image</label>
                                <div class="mb-1">
                                    <input type="file" name="slide_2" accept="image/*,video/*" class="form-control" onfocus="focused(this)"
                                        onfocusout="defocused(this)">
                                    <div class="invalid-feedback">Veuillez selectionner une image/video.</div>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control" name="title_2" onfocus="focused(this)"
                                        placeholder="Titre" onfocusout="defocused(this)"
                                        value="{{$home_slide_2['title'] ?? ''}}">
                                    <div class="invalid-feedback">Veuillez saisir une title.</div>
                                </div>

                                <label class="mt-3">Video 2</label>
                                <div class="mb-1">
                                    <input type="file" name="slide_3" accept="image/*,video/*" class="form-control"
                                        onfocus="focused(this)" onfocusout="defocused(this)">
                                    <div class="invalid-feedback">Veuillez selectionner une image/video.</div>
                                </div>
                                <div class="mb-3">
                                    <input type="text" class="form-control" name="title_3" onfocus="focused(this)"
                                        placeholder="Titre" onfocusout="defocused(this)"
                                        value="{{$home_slide_3['title'] ?? ''}}">
                                    <div class="invalid-feedback">Veuillez saisir une title.</div>
                                </div>

                                <div class="d-flex justify-content-end mt-3">
                                    <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                {{-- End media section --}}

            </div>

        </div>
    </div>



    @include('administration.components.dropzone')
    @include('administration.layouts.footers.auth.footer')
</div>

@endsection