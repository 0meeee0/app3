@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Reseau sociaux'])
    @php
        $facebook = \App\Models\SocialMedia::get_social_link_by_name('facebook');  
        $instagram = \App\Models\SocialMedia::get_social_link_by_name('instagram');  
        $pinterest = \App\Models\SocialMedia::get_social_link_by_name('pinterest');  
        $twitter = \App\Models\SocialMedia::get_social_link_by_name('twitter');  
        $whatsapp = \App\Models\SocialMedia::get_social_link_by_name('whatsapp');  
    @endphp


    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-12">
                @include('administration.components.SessionAlerts')
                <div class="row mb-3 d-flex justify-content-center">
                    {{-- Start social media links --}}
                    <div class="col-12 col-sm-12 col-md-8 col-lg-8">
                        <div class="card flex-fill mb-3 py-3">
                            <div class="card-header d-flex justify-content-between py-0">
                                <h5 class="mb-0">Reseau sociaux</h5>
                            </div>
                            <div class="container px-3 pt-3">
                                <form action="{{route('social-media-update')}}" method="post">
                                    @csrf
                                    @method('PUT')

                                    <label class="mt-1">Facebook</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="social[facebook]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$facebook['link'] ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir un lien.</div>
                                    </div>
                                    <label class="mt-1">Instagram</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="social[instagram]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$instagram['link'] ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir un lien.</div>
                                    </div>
                                    <label class="mt-1">Pinterest</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="social[pinterest]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$pinterest['link'] ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir un lien.</div>
                                    </div>
                                    <label class="mt-1">Twitter</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="social[twitter]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$twitter['link'] ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir un lien.</div>
                                    </div>
                                    <label class="mt-1">Whatsapp</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="social[whatsapp]" onfocus="focused(this)" onfocusout="defocused(this)" value="{{$whatsapp['link'] ?? ''}}" >
                                        <div class="invalid-feedback">Veuillez saisir un lien.</div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-end mt-3">
                                        <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Modifier</button>
                                    </div>
                                    
                                </form>
                            </div>
                        </div>                            
                    </div>
                    {{-- End social media links --}}
                </div>
            </div>
        </div>



        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
    </div>

@endsection