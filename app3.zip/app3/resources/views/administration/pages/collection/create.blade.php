@extends('administration.layouts.app', ['class' => 'g-sidenav-show bg-gray-100'])

@section('content')
    @include('administration.layouts.navbars.auth.topnav', ['title' => 'Collections'])

    <div class="container-fluid py-4">
        <div class="row mb-5">
            <div class="col-lg-9 col-12 mx-auto">
                <div class="card card-body mt-4">
                    <h6 class="mb-0">Nouveau Collection</h6>
                    <hr class="horizontal dark my-3">

                    @include('administration.components.SessionAlerts')

                    <form method="POST" action="{{ route('collection.store') }}"  class="needs-validation" novalidate>
                        @csrf
                        <label for="name" class="form-label"> Titre</label>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="name" name="title" onfocus="focused(this)"
                                onfocusout="defocused(this)" required>
                        </div>
                        <label class="mt-4"> Courte description</label>
                        <textarea name="short_description" rows="2" class="w-100 form-control" required></textarea>

                        <label class="mt-4"> Description</label>
                        <textarea name="description" rows="7" id="editor" class="w-100 form-control"  required></textarea>
<div class="input-group mb-3">
                            <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                            <input type="text" class="form-control" placeholder=""
                                aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                        </div>

                        <label class="mt-4">Images</label>
                        <div class="input-group mb-3">
                            <button class="btn btn-outline-secondary" type="button" id="button-addon1"
                                data-bs-toggle="modal" data-bs-target="#dropzoneImagesCheck">Ajouter</button>
                            <input type="text" class="form-control" placeholder=""
                                aria-label="Example text with button addon" id="selected_images_input_value" aria-describedby="button-addon1" readonly>
                        </div>

                        <div class="images-thumb d-flex" id="images-thumb"></div>
                        <div id="selected_images"></div>

                        <div class="d-flex justify-content-end mt-4">
                            <a href="{{ route('collection.index') }}">
                                <button type="button" class="btn bg-gradient-primary m-0 ms-2">Annuler</button>
                            </a>
                            <button type="submit" class="btn bg-gradient-primary m-0 ms-2">Ajouter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        @include('administration.components.dropzone')
        @include('administration.layouts.footers.auth.footer')
        
        <script type="text/javascript">
            // JavaScript to add validation styling to the form
            // (Assuming you have included Bootstrap's JS library)
            (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
            })();
        </script>
    </div>
@endsection
