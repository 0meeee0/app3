/*
  Theme Name: Corine- Personal Portfolio Template
  Author: ThemexHunter
  Description: Multi header Personal template.
  Version: 1.0
*/

/* JS Index
-----------------------------------
1. preloader
2. Type Text
3. Tilt js
4. Service slider
5. Banner slider
6. Progress Bar
7. Cercle Progress Bar
8. Portfolio filter
9. counter Up 
10. Hide navigation
11. Search model
*/

!(function (e) {
    "use strict";
    e(function () {
        e(document).on(
            "click",
            "[data-lightbox]",
            lity.options(
                "template",
                '<div class="lity" role="dialog" aria-label="Dialog Window (Press escape to close)" tabindex="-1"><div class="lity-wrap" data-lity-close role="document"><div class="lity-loader" aria-hidden="true">Loading...</div><div class="lity-container"><div class="lity-content"></div><div class="lity-close" data-lity-close aria-label="Close (Press escape to close)"><span class="btn-line"></span></div></div></div></div>'
            )
        ),
            e('.nav-link[href^="#"]').each(function () {
                e(this).animatedModal({
                    animatedIn: "fadeIn",
                    animatedOut: "fadeOut",
                    animationDuration: "0s",
                    beforeOpen: function () {
                        e("#overlay-effect")
                            .addClass("animate-down")
                            .removeClass("animate-up"),
                            e("#" + this.modalTarget).css({
                                animationDelay: ".5s",
                                animationFillMode: "both",
                            });
                    },
                    afterOpen: function () {
                        e("#" + this.modalTarget).css({
                            animationFillMode: "none",
                        });
                    },
                    beforeClose: function () {
                        e("#overlay-effect")
                            .addClass("animate-up")
                            .removeClass("animate-down"),
                            e("#" + this.modalTarget).css({
                                animationDelay: ".5s",
                                animationFillMode: "both",
                            });
                    },
                    afterClose: function () {
                        e("#" + this.modalTarget).css({
                            animationFillMode: "none",
                        });
                    },
                });
            }),
            e(".lightbox-wrapper").each(function () {
                e('.nav-link[href^="#' + this.id + '"]').length ||
                    e(this).hide();
            }),
            /* Preloader */
            $(window).on("load", function () {
                $(".hola").delay(2000).fadeOut("slow");
            });

        /* Type Text*/
        if ($("#typewriting").length) {
            var app = document.getElementById("typewriting");
            var typewriter = new Typewriter(app, {
                loop: true,
            });
            typewriter
                .typeString("Way to achieve success")
                .pauseFor(2000)
                .deleteAll()
                .typeString("Style to achieve success")
                .pauseFor(2000)
                .deleteAll()
                .typeString("Method to achieve success")
                .start();
        }
        if ($("#personal").length) {
            var app = document.getElementById("personal");
            var personal = new Typewriter(app, {
                loop: true,
            });
            personal
                .typeString("UI/UX Designer.")
                .pauseFor(2000)
                .deleteAll()
                .typeString("Web Developer.")
                .pauseFor(2000)
                .deleteAll()
                .typeString("Wordpress Developer.")
                .start();
        }

        /* TILT JS */
        const tilt = $(".js-tilt").tilt();
        tilt.on("change", function (e, transforms) {});
        $(".img-tilt").tilt({
            maxTilt: 3,
            glare: false,
            maxGlare: 0.9,
            reverse: true,
        });

        /* SERVICE SLIDER */
        var swiper = new Swiper(".service-slider", {
            slidesPerView: "3",
            spaceBetween: 30,
            autoplay: true,
            allowTouchMove: true,
            speed: 300,
            loop: true,
            keyboard: {
                enabled: true,
                onlyInViewport: true,
            },
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            breakpoints: {
                0: {
                    slidesPerView: 1,
                },
                767: {
                    slidesPerView: 2,
                },
                1000: {
                    slidesPerView: 3,
                },
            },
        });

        /* BANNER SLIDER */
        var swiper = new Swiper(".banner-slider", {
            direction: "vertical",
            slidesPerView: 1,
            spaceBetween: 0,
            loop: true,
            speed: 500,
            mousewheel: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            autoplay: {
                delay: 6500,
                disableOnInteraction: false,
            },
        });

        /* Progress Bar */
        $(document).ready(function () {
            $(".bar1").barfiller({ duration: 3000 });
            $(".bar2").barfiller({ duration: 3000 });
            $(".bar3").barfiller({ duration: 3000 });
            $(".bar4").barfiller({ duration: 3000 });
            $(".bar5").barfiller({ duration: 3000 });
            $(".bar6").barfiller({ duration: 3000 });
            $(".bar7").barfiller({ duration: 3000 });
        });

        /* circle progressBar */
        /*
         * Example 2:
         *
         * - default gradient
         * - listening to `circle-animation-progress` event and display the animation progress: from 0 to 100%
         */
        var progressBarOptions = {
            startAngle: -1.55,
            size: 140,
            value: 0.75,
            emptyFill: "rgba(25, 25, 25, 1)",
            fill: {
                color: "#f7e626",
            },
        };

        $(".circle")
            .circleProgress(progressBarOptions)
            .on(
                "circle-animation-progress",
                function (event, progress, stepValue) {
                    $(this)
                        .find("strong")
                        .text(String(stepValue.toFixed(2)).substr(1));
                }
            );

        $("#circle-b").circleProgress({
            value: 0.66,
            emptyFill: "rgba(25, 25, 25, 1)",
            fill: {
                color: "#f7e626",
            },
        });

        $("#circle-c").circleProgress({
            value: 0.6,
            emptyFill: "rgba(25, 25, 25, 1)",
            fill: {
                color: "#f7e626",
            },
        });

        $("#circle-d").circleProgress({
            value: 0.85,
            emptyFill: "rgba(25, 25, 25, 1)",
            fill: {
                color: "#f7e626",
            },
        });

        /* portfolio-area */
        $(".portfolio-area").on("click", "button", function () {
            var filterValue = $(this).attr("data-filter");
            $grid.isotope({ filter: filterValue });
        });

        var $grid = $(".grid.filter").isotope({
            itemSelector: ".grid-item",
            percentPosition: true,

            masonry: {
                // use outer width of grid-sizer for columnWidth
                columnWidth: ".grid-item",
            },
        });
        //for filter menu active class
        $(".portfolio-menu button").on("click", function (event) {
            $(this).siblings(".active").removeClass("active");
            $(this).addClass("active");
            event.preventDefault();
        });

        /* counter Up */
        $(".counter").counterUp({
            delay: 10,
            time: 1000,
        });

        /*------------------
		Navigation
	--------------------*/
        $(".nav-switch-btn").on("click", function () {
            if (localStorage.getItem("navMenu") == null) {
                localStorage.setItem("navMenu", "show");
                $(".main-menu").slideDown(400);
            } else if (localStorage.getItem("navMenu") == "show") {
                localStorage.removeItem("navMenu");
                $(".main-menu").slideUp(400);
            }
        });

        if (localStorage.getItem("navMenu") == "show") {
            $(".main-menu").slideDown(400);
        }

        /*------------------
		Search model
	--------------------*/
        $(".search-btn").on("click", function () {
            $(".search-model").fadeIn(400);
        });

        $(".search-close-switch").on("click", function () {
            $(".search-model").fadeOut(400, function () {
                $("#search-input").val("");
            });
        });

        /* overlay menu */
        $("#toggle").click(function () {
            $(this).toggleClass("active");
            $("#overlay").toggleClass("open");
        });

        /* slide menu */
        $("#slide-toggle").click(function () {
            $(this).toggleClass("active");
            $("#side-nav").toggleClass("open");
        });

        /* mobile menu */
        $("#menuToggle").click(function () {
            $(this).toggleClass("active");
            $("#mobile-menu").toggleClass("open");
        });
    });
})(jQuery);

// Start slide Show JS
$(document).ready(function () {
    function startAnimations() {
        $('.bg-container .cont').hide();
        $('.bg-container').css('height', '0');
        // Start the animation for load-bar-1 by adding the class
        $('.load-bar-1').addClass('animate');
        $('#slide-1').addClass('show-slide'); // Show slide-1
        $('.bg-container.bg-1').css('height', '50px');
        $('.bg-container.bg-1  .cont').css('display', 'flex');

        $('#slide-2').removeClass('show-slide'); // Hide slide-2
        $('#slide-3').removeClass('show-slide'); // Hide slide-3

        // Wait for load-bar-1 animation to complete
        setTimeout(function () {
            $('.bg-container  .cont').hide();
            $('.bg-container').css('height', '0');
            // Start the animation for load-bar-2 by adding the class
            $('.load-bar-2').addClass('animate');
            $('.bg-container.bg-2').css('height', '50px');
            $('.bg-container.bg-2 .cont').css('display', 'flex');

            $('#slide-1').removeClass('show-slide'); // Hide slide-1
            $('#slide-2').addClass('show-slide'); // Show slide-2
            $('#slide-3').removeClass('show-slide'); // Hide slide-3

            // Wait for load-bar-2 animation to complete
            setTimeout(function () {
                $('.bg-container .cont').hide();
                $('.bg-container').css('height', '0');
                // Start the animation for load-bar-3 by adding the class
                $('.load-bar-3').addClass('animate');
                $('.bg-container.bg-3').css('height', '50px');
                $('.bg-container.bg-3 .cont').css('display', 'flex');

                $('#slide-1').removeClass('show-slide'); // Hide slide-1
                $('#slide-2').removeClass('show-slide'); // Hide slide-2
                $('#slide-3').addClass('show-slide'); // Show slide-3

                // Reset all bars to gray after load-bar-3 animation completes
                setTimeout(function () {
                    $('.bg-container .cont').hide();
                    $('.bg-container').css('height', '0');
                    $('.load-bar-1, .load-bar-2, .load-bar-3').removeClass('animate');
                    $('#slide-1, #slide-2, #slide-3').removeClass('show-slide');
                    setTimeout(startAnimations, 1000); // Delay before restarting the animation
                }, 5000); // 5 seconds for load-bar-3 animation
            }, 5000); // 5 seconds for load-bar-2 animation
        }, 5000); // 5 seconds for load-bar-1 animation
    }

    startAnimations(); // Start the animation when the page loads
});
// End slide Show JS