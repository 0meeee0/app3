/* document.addEventListener("DOMContentLoaded", function() {
    var navbarToggle = document.querySelector(".navbar-toggler");
    var navbarCollapse = document.querySelector(".navbar-collapse");
  
    navbarToggle.addEventListener("click", function() {
      navbarCollapse.classList.toggle("show");
    });
  });
   */

  

// Image background chaning every 5 seconds
/* const dressingHead = document.querySelector('#dressing-images');
const images = ['assets/images/dressing/1.jpg', 'assets/images/dressing/2.jpg', 'assets/images/dressing/3.webp', 'assets/images/dressing/4.jpg'];
let currentIndex = 0;

function changeBackgroundImage() {
  dressingHead.style.backgroundImage = `url('${images[currentIndex]}')`;
  currentIndex = (currentIndex + 1) % images.length;
}

setInterval(changeBackgroundImage, 5000); */


const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
      if (entry.isIntersecting) {
          entry.target.classList.add('show');
      }
  });
});

const hiddenElements = document.querySelectorAll('.hidden');
hiddenElements.forEach((el) => observer.observe(el));

//sideways
const observer_side = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
      if (entry.isIntersecting) {
          entry.target.classList.add('show-side');
      }
  });
});

const hiddenElements_side = document.querySelectorAll('.hidden-side');
hiddenElements_side.forEach((el) => observer_side.observe(el));

//bottom

const observer_bottom = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
      if (entry.isIntersecting) {
          entry.target.classList.add('show-bottom');
      }
  });
});

const hiddenElements_bottom = document.querySelectorAll('.hidden-bottom');
hiddenElements_bottom.forEach((el) => observer_bottom.observe(el));

//right
const observer_right = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
      if (entry.isIntersecting) {
          entry.target.classList.add('show-right');
      }
  });
});

const hiddenElements_right = document.querySelectorAll('.hidden-right');
hiddenElements_right.forEach((el) => observer_right.observe(el));


// Start Category Silder 
document.addEventListener("DOMContentLoaded", function () {
  const carousel = document.querySelector(".splide__arrows");
  const carouselList = document.querySelector(".splide__list");
  const prevButton = document.querySelector(".splide__arrow--prev");
  const nextButton = document.querySelector(".splide__arrow--next");
  let itemsToShow = calculateItemsToShow(); // Change from const to let
  let itemWidth = 0; // Will be updated later in the function
  let currentIndex = 0;

  function calculateItemsToShow() {
    // Calculate the number of items to show based on the available width
    const screenWidth = window.innerWidth;
    return screenWidth >= 1200 ? 3.25 : screenWidth >= 768 ? 1.5 : screenWidth >= 510 ? 1 : 1;
  }

  function updateCarouselPosition() {
    const offset = -currentIndex * itemWidth;
    carouselList.style.transform = `translateX(${offset}px)`;
  }

  function showHideNavigation() {
    prevButton.style.display = currentIndex === 0 ? "none" : "block";
    nextButton.style.display =
      currentIndex >= carouselList.children.length - itemsToShow
        ? "none"
        : "block";
  }

  function handleNextSlide() {
    if (currentIndex < carouselList.children.length - itemsToShow) {
      currentIndex++;
      updateCarouselPosition();
      showHideNavigation();
    }
  }

  function handlePrevSlide() {
    if (currentIndex > 0) {
      currentIndex--;
      updateCarouselPosition();
      showHideNavigation();
    } else {
      // If currentIndex is 0, move to the last set of visible items
      currentIndex = carouselList.children.length - itemsToShow;
      updateCarouselPosition();
      showHideNavigation();
    }
  }

  function handleResize() {
    itemsToShow = calculateItemsToShow();
    itemWidth = carousel.clientWidth / itemsToShow;
    currentIndex = 0;
    updateCarouselPosition();
    showHideNavigation();
  }

  nextButton.addEventListener("click", handleNextSlide);
  prevButton.addEventListener("click", handlePrevSlide);
  window.addEventListener("resize", handleResize);

  // Initialize carousel
  handleResize();
});

// End Category Slider

// Generates a random addition equation for the CAPTCHA
function generateCaptcha() {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const equation = `${num1} + ${num2}`;
    return { equation, answer: num1 + num2 };
}

// Initializes the CAPTCHA challenge
function initializeCaptcha() {
    const captcha = generateCaptcha();
    document.getElementById("captchaEquation").textContent = captcha.equation;
    document.getElementById("userAnswer").value = "";
    document.getElementById("resultMessage").textContent = "";
    return captcha.answer;
}

// Checks if the user's answer is correct
function checkAnswer() {
  const userAnswer = parseInt(document.getElementById("userAnswer").value);
  if (!isNaN(userAnswer)) {
      const correctAnswer = initializeCaptcha();
      if (userAnswer === correctAnswer) {
          document.getElementById("resultMessage").textContent = "Correct! You may proceed.";
          return true;
      } else {
          document.getElementById("resultMessage").textContent = "Incorrect answer. Please try again.";
          return false;
      }
  } else {
      document.getElementById("resultMessage").textContent = "Please enter a valid number.";
      return false;
  }
}


// Initialize the CAPTCHA challenge when the page loads
window.onload = function() {
    initializeCaptcha();
};

